package Engine.Anthony;

import Engine.ShaderProgram;
import Engine.UniformsMap;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;

import static org.lwjgl.opengl.GL30.glGenVertexArrays;

public class Kurva extends Object2d {


    public Kurva(List<ShaderProgram.ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color) {
        super(shaderModuleDataList, vertices, color);
        curve();
        setupVAOVBOCurve();
        uniformsMap = new UniformsMap(getProgramId());
        uniformsMap.createUniform("uni_color");
    }

    //fungsi curve
    public void curve() {
        if(vertices.size() < 2)
            return;
        objectsCurve.clear();
        objectsCurve.add(vertices.get(0));
        int size = vertices.size()-1;
        for (float t = 0; t <= 1; t += 0.01) {
            float x = 0, y = 0;
            int pangkat = vertices.size()-1;
            for(int i=0; i< vertices.size(); i+=1){
                x += comb(size,i) * Math.pow(1-t,pangkat)* Math.pow(t,i) * vertices.get(i).x;
                y += comb(size,i) * Math.pow(1-t,pangkat)* Math.pow(t,i) * vertices.get(i).y;
                pangkat--;
            }
            objectsCurve.add(new Vector3f(x, y, 0));
        }
        objectsCurve.add(vertices.get(vertices.size()-1));
    }

    public int comb(int n, int r){
        int hasil;
        hasil = factorial(n)/(factorial(n - r)* factorial(r));
        return hasil;
    }

    public int factorial(int angka) {
        if (angka == 1 || angka == 0 )
            return 1;
        else
            return angka * factorial(angka - 1);
    }


}
