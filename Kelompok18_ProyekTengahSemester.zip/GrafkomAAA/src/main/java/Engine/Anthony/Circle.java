package Engine.Anthony;

import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;

public class Circle extends Object2d{
        float pusatX;
        float pusatY;
        float jari;
        int titik;

        public Circle(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> vertis, Vector4f color, float pX, float pY, float jari, int titik) {
                super(shaderModuleDataList, vertis , color);

                // set pusat, jari dan banyak titik
                this.pusatX = pX;
                this.pusatY = pY;
                this.jari = jari;
                this.titik = titik;

                System.out.println(vertis.size());
        }
}