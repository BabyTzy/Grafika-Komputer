package Engine.Anthony;
import Engine.ShaderProgram;
import Engine.Utils;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL15;

import java.util.List;

import static org.lwjgl.opengl.GL15.*;

public class Rect2 extends Object2d {
    List<Integer> index;
    int ibo;
    float pX, pY;
    public Rect2(List<ShaderProgram.ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color, List<Integer> index, float pX, float pY) {
        super(shaderModuleDataList, vertices, color);
        this.index = index;
        this.pX = pX;
        this.pY = pY;

        ibo = glGenBuffers();
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
        GL15.glBufferData(GL_ELEMENT_ARRAY_BUFFER, Utils.listoInt(index), GL_STATIC_DRAW);
    }


    public boolean checkOverlapKotak(float x, float y) {
        float size = 0.1f;

        // cek titik kiri atas masuk dalam kotak
        if ((x-size) >= (pX-size) && (x-size) <= (pX+size)){
            if ((y+size) >= (pY-size) && (y+size) <= (pY+size)) {
                return true;
            }
        }

        // cek titik kiri bawah
        if ((x-size) >= (pX-size) && (x-size) <= (pX+size)){
            if ((y-size) >= (pY-size) && (y-size) <= (pY+size)) {
                return true;
            }
        }

        // cek titik kanan atas masuk dalam kotak
        if ((x+size) >= (pX-size) && (x+size) <= (pX+size)){
            if ((y+size) >= (pY-size) && (y+size) <= (pY+size)) {
                return true;
            }
        }
        // cek titik kanan bawah
        if ((x+size) >= (pX-size) && (x+size) <= (pX+size)){
            if ((y-size) >= (pY-size) && (y-size) <= (pY+size)) {
                return true;
            }
        }

        // sisa false
        return false;
    }
    public void setpX(float pX) {
        this.pX = pX;
    }

    public void setpY(float pY) {
        this.pY = pY;
    }
    public boolean checkOverlap(float x, float y){
        float size = 0.1f;

        // cek x
        if (x >= (pX-size) && x <= (pX+size)){
            if (y >= (pY-size) && y <= (pY+size)){
                return true;
            }
            return false;
        }
        return false;
    }

    public Vector4f getColor() {
        return this.color;

    }

}
