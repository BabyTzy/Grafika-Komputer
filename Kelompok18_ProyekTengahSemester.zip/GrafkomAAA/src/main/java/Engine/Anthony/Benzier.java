package Engine.Anthony;

import Engine.Camera;
import Engine.Projection;
import Engine.ShaderProgram;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

import static org.lwjgl.opengl.GL11.*;
import static org.lwjgl.opengl.GL11.GL_LINE_STRIP;

public class Benzier extends Object {
    public Benzier(List<ShaderProgram.ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color, List<Vector3f> titikYangAda) {
        super(shaderModuleDataList, vertices, color);
        BezierCurve(titikYangAda);
        setupVAOVBO();
    }

    // Fungsi untuk menghitung segitiga pascal
    public int factorial(int angka) {
        if (angka == 0) {
            return 1;
        }
        int hasil = 1;

        for (int i = 2; i <= angka; i++) {
            hasil = hasil * i;
        }
        return hasil;
    }

    // Untuk menghitung factorial segitiga pascal
    public int koefisienPascal(int n, int r) {
        return factorial(n) / (factorial(n - r) * factorial(r));
    }

    public void BezierCurve(List<Vector3f> titikYangAda) {
        List<Vector3f> listTitikBenzier = new ArrayList<>();

        for (float t = 0; t <= 1; t = t + 0.01f) {
            float hasilX = 0.0f; // TemporaryX
            float hasilY = 0.0f; // TemporaryY

            int n = titikYangAda.size() - 1; //Ada brp banyak titik

            // Cari y dengan cara pakai rumus segitiga pascal (looping juga)
            // Pakai kombinasi buat cari konstanta
            for (int polinom = 0; polinom <= n; polinom++) {
                // constanta * (1-t)^(n-polinom) * t^polinom * titikSekarang
                float perhitungan = koefisienPascal(n, polinom) * (float) (Math.pow(1 - t, n - polinom) * Math.pow(t, polinom));

                hasilX = hasilX + (titikYangAda.get(polinom).x * perhitungan);
                hasilY = hasilY + (titikYangAda.get(polinom).y * perhitungan);
            }

            // Add ke List
            listTitikBenzier.add(new Vector3f(hasilX, hasilY, 0.0f));
        }
        vertices = listTitikBenzier;
    }

    public void draw(Camera camera, Projection projection) {
        drawSetup(camera, projection);
        glLineWidth(0); //Ketebalan garis
        glPointSize(0); //Besar kecil vertex
        glDrawArrays(GL_LINE_STRIP, 0, vertices.size());
    }
}