package Engine.Anthony;

import Engine.ShaderProgram;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.List;

import static org.lwjgl.opengl.GL11.*;


public class Kotak extends Object2d{
    double cx,cy,panjang,lebar;
    double x,y;
    int poinVertices;


    public Kotak(List<ShaderProgram.ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color,
                 double cx, double cy, double panjang, double lebar, int poinVertices) {
        super(shaderModuleDataList, vertices, color);
        this.cx = cx;
        this.cy = cy;
        this.panjang = panjang;
        this.lebar = lebar;
        this.poinVertices = poinVertices;
        CreateKotak();
        setupVAOVBO();



    }

    public double getCx() {
        return cx;
    }

    public double getCy() {
        return cy;
    }

    public double getPanjang() {
        return panjang;
    }

    public double getLebar() {
        return lebar;
    }

    public double getX() {
        return x;
    }

    public double getY() {
        return y;
    }

    public void setCx(double x){this.cx = x;}
    public void setCy(double y){this.cy = y;}
    public int getpoinVertices(){return poinVertices;}

    public void CreateKotak(){

        //clear vertices
        vertices.clear();

        for (float i = 45; i < 405; i+=90) {
            x = cx + ((panjang) * Math.cos(Math.toRadians(i)));
            y = cy + ((lebar) * Math.sin(Math.toRadians(i)));
            vertices.add(new Vector3f((float) x, (float) y, 0.0f));
        }



    }

    public void MoveKotak(double cx,double cy) {
        this.cx = cx;
        this.cy = cy;
        CreateKotak();
        setupVAOVBO();
    }

    public void draw(){
        drawSetup();

//        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
//        glDrawElements(GL_TRIANGLE_FAN, index.size(),GL_UNSIGNED_INT, 0);
        glDrawArrays(GL_TRIANGLE_FAN,0,vertices.size());


        //GL_LINES
        //GL_LINE_STRIP
        //GL_LINE_LOOP
        //GL_TRIANGLES
        //GL_TRIANGLE_FAN
        //GL_POINT

    }
}
