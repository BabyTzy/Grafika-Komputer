package Engine.Anthony;

import Engine.ShaderProgram;
import Engine.UniformsMap;
import Engine.Utils;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL15;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.lwjgl.opengl.GL15.*;
import static org.lwjgl.opengl.GL20.*;
import static org.lwjgl.opengl.GL30.glBindVertexArray;
import static org.lwjgl.opengl.GL30.glGenVertexArrays;

public class Object2d extends ShaderProgram {

    List<Vector3f> vertices;
    List<Vector3f> verticesColor;
    int vao;
    int vbo;
    int vboColor;
    ArrayList<Vector3f> objectsCurve = new ArrayList<Vector3f>();

    UniformsMap uniformsMap;
    Vector4f color;

    public Object2d(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color) {
        super(shaderModuleDataList);
        this.vertices = vertices;
        setupVAOVBO();
        uniformsMap = new UniformsMap(getProgramId());
        uniformsMap.createUniform("uni_color");
        this.color = color;
    }
    public Object2d(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, List<Vector3f> verticesColor) {
        super(shaderModuleDataList);
        this.vertices = vertices;
        this.verticesColor = verticesColor;
        setupVAOVBOWithVerticesColor();

    }
    public void setupVAOVBOWithVerticesColor(){
        //setup Vao
        vao = glGenVertexArrays();
        glBindVertexArray(vao);
        //Setup VBO
        vbo = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        GL15.glBufferData(GL_ARRAY_BUFFER, Utils.listoFloat(vertices), GL_STATIC_DRAW);
        //Setup Vbo Color
        vboColor = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, vboColor);
        glBufferData(GL_ARRAY_BUFFER, Utils.listoFloat(verticesColor), GL_STATIC_DRAW);

    }
    public void setupVAOVBO(){
        vao = glGenVertexArrays();
        glBindVertexArray(vao);

        vbo = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        glBufferData(GL_ARRAY_BUFFER, Utils.listoFloat(vertices), GL_STATIC_DRAW);

    }
    public void draw(){
        drawSetup();
        //draw vertice
        //Optional
        glLineWidth(1); //ketebalan garis
        glPointSize(0); //besar kecil vertex

        //wajib
        //GL TRIANGLE BISA DICUSTOM
        //kalau mau garis bisa GL_LINE dsb
        //INI YANG BIASA SERING DIPAKAI =
        //GL_LINE_STRIP
        //GL_LINE_LOOP
        //GL_TRIANGLES
        //GL_TRIANGLE_FAN
        //GL_POINT

        //First ini buat ngegambar dari index keberapa, kalau mau digambar semua dari 0 berarti.
        //vertices.size ini buat ngasi tau ngegambar dari titik first keberapa hingga keberapa, kalau mau semuanya lgsg vertices.size
        //kalau mau sampai ke dua ya isi langsung habis first lgsg koma 2
        glDrawArrays(GL_TRIANGLE_FAN,0,vertices.size());
    }
    public void drawWithVerticesColor(){
        drawSetupWithVerticesColor();
        //draw vertice
        //Optional
        glLineWidth(1); //ketebalan garis
        glPointSize(0); //besar kecil vertex

        //wajib
        //GL TRIANGLE BISA DICUSTOM
        //kalau mau garis bisa GL_LINE dsb
        //INI YANG BIASA SERING DIPAKAI =
        //GL_LINE_STRIP
        //GL_LINE_LOOP
        //GL_TRIANGLES
        //GL_TRIANGLE_FAN
        //GL_POINT

        //First ini buat ngegambar dari index keberapa, kalau mau digambar semua dari 0 berarti.
        //vertices.size ini buat ngasi tau ngegambar dari titik first keberapa hingga keberapa, kalau mau semuanya lgsg vertices.size
        //kalau mau sampai ke dua ya isi langsung habis first lgsg koma 2
        glDrawArrays(GL_TRIANGLES,0,vertices.size());
    }
    public void drawLine(){
        drawSetup();
        //Optional
        glLineWidth(10); //ketebalan garis
        glPointSize(10); //besar kecil vertex

        glDrawArrays(GL_LINE_STRIP,0,vertices.size());
    }

    public void setupVAOVBOCurve(){
        // set vao
        vao = glGenVertexArrays();
        glBindVertexArray(vao);
        // set vbo
        vbo = glGenBuffers();
        glBindBuffer(GL_ARRAY_BUFFER, vbo);
        // mengirim vertices
        glBufferData(GL_ARRAY_BUFFER, Utils.listoFloat(objectsCurve), GL_STATIC_DRAW);
    }
//    public void drawCurve(List<Vector3f> points){
//        Object2d garis = new Object2d(
//                Arrays.asList(
//                        new ShaderProgram.ShaderModuleData(
//                                "resources/shaders/scene.vert",
//                                GL_VERTEX_SHADER),
//                        new ShaderProgram.ShaderModuleData(
//                                "resources/shaders/scene.frag",
//                                GL_FRAGMENT_SHADER)
//                ),
//                new ArrayList<>(points),
//                new Vector4f(0.0f, 1.0f, 1.0f, 0.0f)
//        );
//        if (vertices.size() == 2) {
//            drawLine();
//            return;
//        }
//        setupVAOVBOCurve();
//        drawSetup();
//        glLineWidth(8);
//        glPointSize(0);
//        glDrawArrays(GL_LINE_STRIP, 0, objectsCurve.size());
//    }
//
//    //fungsi curve
//    public void curve() {
//        if(vertices.size() < 2)
//            return;
//        objectsCurve.clear();
//        objectsCurve.add(vertices.get(0));
//        int size = vertices.size()-1;
//        for (float t = 0; t <= 1; t += 0.01) {
//            float x = 0, y = 0;
//            int pangkat = vertices.size()-1;
//            for(int i=0; i< vertices.size(); i+=1){
//                x += comb(size,i) * Math.pow(1-t,pangkat)* Math.pow(t,i) * vertices.get(i).x;
//                y += comb(size,i) * Math.pow(1-t,pangkat)* Math.pow(t,i) * vertices.get(i).y;
//                pangkat--;
//            }
//            objectsCurve.add(new Vector3f(x, y, 0));
//        }
//        objectsCurve.add(vertices.get(vertices.size()-1));
//    }
//
//    public int comb(int n, int r){
//        int hasil;
//        hasil = factorial(n)/(factorial(n - r)* factorial(r));
//        return hasil;
//    }
//
//    public int factorial(int angka) {
//        if (angka == 1 || angka == 0 )
//            return 1;
//        else
//            return angka * factorial(angka - 1);
//    }
// fungsi bantu buat bezier

    public void addVertices(Vector3f newVertices){
        vertices.add(newVertices);
        setupVAOVBO();
    }
    public void addVertices(int index, Vector3f newVertices){
        vertices.add(newVertices);
        setupVAOVBO();
    }
    public void removeVertices(int index){
        vertices.remove(index);
        setupVAOVBO();
    }
    public void drawSetup(){
        bind();
        uniformsMap.setUniform("uni_color", color);
        //Bind VBO
        glEnableVertexAttribArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, vbo); //yang di kirim
        //kirim ke 0
        //karena 1 vertex itu 3 (x,y,z) maka size 3, kalau 2 vertex (x,y) maka size 2
        //kita kasih tau yang kita kirim tipe datanya GL_FLOAT
        //pointer 0 karena ingin komputer baca VBO dari awal. Default nya emang 0.
        glVertexAttribPointer(0,3,GL_FLOAT,false,0,0);
    }

    public void drawSetupWithVerticesColor(){
        bind();

        //Bind VBO
        glEnableVertexAttribArray(0);
        glBindBuffer(GL_ARRAY_BUFFER, vbo); //yang di kirim
        //kirim ke 0
        //karena 1 vertex itu 3 (x,y,z) maka size 3, kalau 2 vertex (x,y) maka size 2
        //kita kasih tau yang kita kirim tipe datanya GL_FLOAT
        //pointer 0 karena ingin komputer baca VBO dari awal. Default nya emang 0.
        glVertexAttribPointer(0,3,GL_FLOAT,false,0,0);

        //Bind VBOColor
        glEnableVertexAttribArray(1);
        glBindBuffer(GL_ARRAY_BUFFER, vboColor); //yang di kirim
        //kirim ke 1
        //karena 1 vertex itu 3 (x,y,z) maka size 3, kalau 2 vertex (x,y) maka size 2
        //kita kasih tau yang kita kirim tipe datanya GL_FLOAT
        //pointer 0 karena ingin komputer baca VBO dari awal. Default nya emang 0.
        glVertexAttribPointer(1,3,GL_FLOAT,false,0,0);
    }

    public int getVerticesSize(){
        return vertices.size();
    }

    public void setVertices(int index,Vector3f newVector){
        vertices.set(index,newVector);
        setupVAOVBO();
    }
    public List<Vector3f> getVertices() {
        return vertices;
    }

}
