package Engine.Anthony;

import Engine.ShaderProgram;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

public class Sphere extends rumusDariCircle2 {
    Float radiusZ;
    int stackCount;
    int sectorCount;
    int option;

    List<Integer> index;
    int ibo;

    public Sphere(List<ShaderProgram.ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color, List<Float> centerPoint, Float radiusX, Float radiusY, Float radiusZ, int sectorCount, int stackCount, int option) {
        super(shaderModuleDataList, vertices, color, centerPoint, radiusX, radiusY);
        this.radiusZ = radiusZ;
        this.sectorCount = sectorCount;
        this.stackCount = stackCount;
        this.option = option;
        if (option == 0) {
            createSphare();
        } else if (option == 1) {
            createSphereElipsoid();
        } else if (option == 2) {
            createHyperboloid1();
        } else if (option == 3) {
            createHyperboloid2();
        } else if (option == 4) {
            createEllipticCone();
        } else if (option == 5) {
            createEllipticParaboloid();
        } else if (option == 6) {
            createHyperboloidParaboloid();
        } else if (option == 7) {
            createBox();
        } else if (option == 8) {
            createCube();
        } else if (option == 9) {
            createTabung();
        }

        setupVAOVBO();
    }

    public void createBox() {
        vertices.clear();
        Vector3f temp = new Vector3f();
        ArrayList<Vector3f> tempVertices = new ArrayList<>();
        //Titik 1 kiri atas belakang
        temp.x = centerPoint.get(0) - radiusX / 2;
        temp.y = centerPoint.get(1) + radiusY / 2;
        temp.z = centerPoint.get(2) - radiusZ / 2;
        tempVertices.add(temp);
        temp = new Vector3f();
        //Titik 2 kiri bawah belakang
        temp.x = centerPoint.get(0) - radiusX / 2;
        temp.y = centerPoint.get(1) - radiusY / 2;
        temp.z = centerPoint.get(2) - radiusZ / 2;
        tempVertices.add(temp);

        temp = new Vector3f();
        //Titik 3 kanan bawah belakang
        temp.x = centerPoint.get(0) + radiusX / 2;
        temp.y = centerPoint.get(1) - radiusY / 2;
        temp.z = centerPoint.get(2) - radiusZ / 2;
        tempVertices.add(temp);

        temp = new Vector3f();
        //Titik 4 kanan atas belakang
        temp.x = centerPoint.get(0) + radiusX / 2;
        temp.y = centerPoint.get(1) + radiusY / 2;
        temp.z = centerPoint.get(2) - radiusZ / 2;
        tempVertices.add(temp);
        temp = new Vector3f();

        //Titik 5 kiri atas depan
        temp.x = centerPoint.get(0) - radiusX / 2;
        temp.y = centerPoint.get(1) + radiusY / 2;
        temp.z = centerPoint.get(2) + radiusZ / 2;
        tempVertices.add(temp);
        temp = new Vector3f();
        System.out.println("Sisi kiri atas depan : " + temp.x + " " + temp.y + " " + temp.z);
        //Titik 6 kiri bawah depan
        temp.x = centerPoint.get(0) - radiusX / 2;
        temp.y = centerPoint.get(1) - radiusY / 2;
        temp.z = centerPoint.get(2) + radiusZ / 2;
        tempVertices.add(temp);
        System.out.println("Sisi kiri bawah depan : " + temp.x + " " + temp.y + " " + temp.z);
        temp = new Vector3f();
        //Titik 7 kanan bawah depan
        temp.x = centerPoint.get(0) + radiusX / 2;
        temp.y = centerPoint.get(1) - radiusY / 2;
        temp.z = centerPoint.get(2) + radiusZ / 2;
        tempVertices.add(temp);
        System.out.println("Sisi kanan bawah depan : " + temp.x + " " + temp.y + " " + temp.z);
        temp = new Vector3f();
        //Titik 8 kanan atas depan
        temp.x = centerPoint.get(0) + radiusX / 2;
        temp.y = centerPoint.get(1) + radiusY / 2;
        temp.z = centerPoint.get(2) + radiusZ / 2;
        tempVertices.add(temp);
        System.out.println("Sisi kanan atas depan : " + temp.x + " " + temp.y + " " + temp.z);
        temp = new Vector3f();

        //kotak belakang
        vertices.add(tempVertices.get(0));
        vertices.add(tempVertices.get(1));
        vertices.add(tempVertices.get(2));

        vertices.add(tempVertices.get(2));
        vertices.add(tempVertices.get(3));
        vertices.add(tempVertices.get(0));
        //kotak depan
        vertices.add(tempVertices.get(4));
        vertices.add(tempVertices.get(5));
        vertices.add(tempVertices.get(6));

        vertices.add(tempVertices.get(6));
        vertices.add(tempVertices.get(7));
        vertices.add(tempVertices.get(4));
        //kotak samping kiri
        vertices.add(tempVertices.get(0));
        vertices.add(tempVertices.get(1));
        vertices.add(tempVertices.get(4));

        vertices.add(tempVertices.get(1));
        vertices.add(tempVertices.get(5));
        vertices.add(tempVertices.get(4));
        //kotak samping kanan
        vertices.add(tempVertices.get(7));
        vertices.add(tempVertices.get(6));
        vertices.add(tempVertices.get(2));

        vertices.add(tempVertices.get(2));
        vertices.add(tempVertices.get(3));
        vertices.add(tempVertices.get(7));
        //kotak atas
        vertices.add(tempVertices.get(0));
        vertices.add(tempVertices.get(4));
        vertices.add(tempVertices.get(7));

        vertices.add(tempVertices.get(4));
        vertices.add(tempVertices.get(7));
        vertices.add(tempVertices.get(3));
        //kotak bawah
        vertices.add(tempVertices.get(1));
        vertices.add(tempVertices.get(5));
        vertices.add(tempVertices.get(6));

        vertices.add(tempVertices.get(5));
        vertices.add(tempVertices.get(6));
        vertices.add(tempVertices.get(2));
    }

    public void createSphare() {
        float pi = (float) Math.PI;
        float sectorStep = 2 * (float) Math.PI / sectorCount;
        float stackStep = (float) Math.PI / sectorCount;
        float sectorAngle, StackAngle, x, y, z;
        for (int i = 0; i <= stackCount; ++i) {
            StackAngle = pi / 2 - i * stackStep;
            x = radiusX * (float) Math.cos(StackAngle);
            y = radiusY * (float) Math.cos(StackAngle);
            z = radiusZ * (float) Math.sin(StackAngle);

            for (int j = 0; j <= sectorCount; ++j) {
                sectorAngle = j * sectorStep;
                Vector3f temp_vector = new Vector3f();
                temp_vector.x = centerPoint.get(0) + x * (float) Math.cos(sectorAngle);
                temp_vector.y = centerPoint.get(1) + y * (float) Math.sin(sectorAngle);
                temp_vector.z = centerPoint.get(2) + z;
                vertices.add(temp_vector);
            }
        }

    }

    public void createCube() {
        float size = 0.2f;

        Vector3f temp = new Vector3f();
        ArrayList<Vector3f> tempVerticels = new ArrayList<>();

        int a = 0; // x
        int b = 1; // y
        int c = 2; // z

        // >> Kotak Belakang
        // titik 1
        temp.x = centerPoint.get(a) - size / 2.0f;
        temp.y = centerPoint.get(b) + size / 2.0f;
        temp.z = centerPoint.get(c) - size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 2
        temp.x = centerPoint.get(a) + size / 2.0f;
        temp.y = centerPoint.get(b) + size / 2.0f;
        temp.z = centerPoint.get(c) - size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 3
        temp.x = centerPoint.get(a) + size / 2.0f;
        temp.y = centerPoint.get(b) - size / 2.0f;
        temp.z = centerPoint.get(c) - size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 4
        temp.x = centerPoint.get(a) - size / 2.0f;
        temp.y = centerPoint.get(b) - size / 2.0f;
        temp.z = centerPoint.get(c) - size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();


        // >> kotak depan
        // titik 1
        temp.x = centerPoint.get(a) - size / 2.0f;
        temp.y = centerPoint.get(b) + size / 2.0f;
        temp.z = centerPoint.get(c) + size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 2
        temp.x = centerPoint.get(a) + size / 2.0f;
        temp.y = centerPoint.get(b) + size / 2.0f;
        temp.z = centerPoint.get(c) + size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 3
        temp.x = centerPoint.get(a) + size / 2.0f;
        temp.y = centerPoint.get(b) - size / 2.0f;
        temp.z = centerPoint.get(c) + size / 2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 4
        temp.x = centerPoint.get(a) - size / 2.0f;
        temp.y = centerPoint.get(b) - size / 2.0f;
        temp.z = centerPoint.get(c) + size / 2.0f;

        tempVerticels.add(temp);

        // clear dulu verticelsnya
        vertices.clear();

        // kotak belakang
        vertices.add(tempVerticels.get(0));
        vertices.add(tempVerticels.get(1));
        vertices.add(tempVerticels.get(2));
        vertices.add(tempVerticels.get(3));

        // kotak depan
        vertices.add(tempVerticels.get(4));
        vertices.add(tempVerticels.get(5));
        vertices.add(tempVerticels.get(6));
        vertices.add(tempVerticels.get(7));

        // kotak samping kiri
        vertices.add(tempVerticels.get(0));
        vertices.add(tempVerticels.get(4));
        vertices.add(tempVerticels.get(7));
        vertices.add(tempVerticels.get(3));

        // kotak samping kanan
        vertices.add(tempVerticels.get(1));
        vertices.add(tempVerticels.get(5));
        vertices.add(tempVerticels.get(6));
        vertices.add(tempVerticels.get(2));

//        tempVerticels.remove(2);

        System.out.println(vertices.size());

    }

    public void createSphereElipsoid() {
        float pi = (float) Math.PI;
        float sectorStep = 2 * (float) Math.PI / sectorCount;
        float stackStep = (float) Math.PI / sectorCount;
        float sectorAngle, StackAngle, x, y, z;
        for (int i = 0; i <= stackCount; ++i) {
            StackAngle = pi / 2 - i * stackStep;
            x = radiusX * (float) Math.cos(StackAngle);
            y = radiusY * (float) Math.cos(StackAngle);
            z = radiusZ * (float) Math.sin(StackAngle);

            for (int j = 0; j <= sectorCount; ++j) {
                sectorAngle = j * sectorStep;
                Vector3f temp_vector = new Vector3f();
                temp_vector.x = centerPoint.get(0) + x * (float) Math.cos(sectorAngle);
                temp_vector.y = centerPoint.get(1) + y * (float) Math.sin(sectorAngle);
                temp_vector.z = centerPoint.get(2) + z;
                vertices.add(temp_vector);
            }
        }
    }


    public void createHyperboloid1() {
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for (double v = -Math.PI / 2; v <= Math.PI / 2; v += Math.PI / 120) {
            for (double u = -Math.PI; u <= Math.PI; u += Math.PI / 120) {
                float x = 0.2f * (float) ((1 / Math.cos(v)) * Math.cos(u));
                float y = 0.2f * (float) ((1 / Math.cos(v)) * Math.sin(u));
                float z = 0.2f * (float) (Math.tan(v));
                temp.add(new Vector3f(x, z, y));
            }
        }
        vertices = temp;
    }

    public void createTabung() {
        ArrayList<Vector3f> sphereVertices = new ArrayList<>();

        float pi = (float) Math.PI;
        float height = 0.5f;
        float sectorStep = 2 * pi / sectorCount;
        float stackStep = height / stackCount;
        float sectorAngle, stackAngle;
        float x, y, z;

        for (int i = 0; i <= stackCount; ++i) {
            stackAngle = i * stackStep;
            x = radiusX;
            y = radiusY;
            z = stackAngle;

            for (int j = 0; j <= sectorCount; ++j) {
                sectorAngle = j * sectorStep;
                Vector3f tempVector = new Vector3f();

                tempVector.x = centerPoint.get(0) + x * (float) Math.cos(sectorAngle);
                tempVector.y = centerPoint.get(1) + y * (float) Math.sin(sectorAngle);
                tempVector.z = centerPoint.get(2) + z;
                sphereVertices.add(tempVector);
            }
        }
        vertices = sphereVertices;
    }

    public void createHyperboloid2() {
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for (double v = -Math.PI / 2; v <= Math.PI / 2; v += Math.PI / 120) {
            for (double u = -Math.PI / 2; u <= Math.PI / 2; u += Math.PI / 120) {
                float x = 0.2f * (float) ((Math.tan(v)) * Math.cos(u));
                float y = 0.2f * (float) ((Math.tan(v)) * Math.sin(u));
                float z = 0.2f * (float) (1 / Math.cos(v));
                temp.add(new Vector3f(x, z, y));

            }
        }
        for (double v = -Math.PI / 2; v <= Math.PI / 2; v += Math.PI / 120) {
            for (double u = -Math.PI / 2; u <= 3 * (Math.PI / 2); u += Math.PI / 120) {
                float x = -0.2f * (float) ((Math.tan(v)) * Math.cos(u));
                float y = -0.2f * (float) ((Math.tan(v)) * Math.sin(u));
                float z = -0.2f * (float) (1 / Math.cos(v));
                temp.add(new Vector3f(x, z, y));

            }
        }
        vertices = temp;
    }

    public void createEllipticCone() {
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for (double v = 0; v <= 2 * Math.PI; v += Math.PI / 60) {
            for (double u = -Math.PI; u <= Math.PI; u += Math.PI / 60) {
                float x = (float) (radiusX * v * Math.cos(u));
                float y = (float) (radiusY * v * Math.sin(u));
                float z = (float) (radiusZ * v);
                temp.add(new Vector3f(x, y, z));
            }
        }
        vertices = temp;
    }

    //    public void createElipticCone() {
//        vertices.clear();
//        ArrayList<Vector3f> temp = new ArrayList<>();
//
//        for(double v = -Math.PI*2; v<= Math.PI*2; v+=Math.PI/18){
//            for(double u = -Math.PI; u<= Math.PI; u+=Math.PI/18){
//                float x = 0.2f * (float)(v * Math.cos(u));
//                float y = 0.2f * (float)((v * Math.sin(u)));
//                float z = 0.2f * (float)(v);
//                temp.add(new Vector3f(x,z,y));
//            }
//        }
//        vertices = temp;
//    }
    // fungsi bantu buat bezier
    public int factorial(int angka) {

        if (angka == 0) {
            return 1;
        }

        int hasil = 1;
        for (int i = 2; i <= angka; i++) {
            hasil = hasil * i;
        }

        return hasil;
    }

    // buat cari koef segitiga pascal
    public int koefisienPascal(int n, int k) {
        return factorial(n) / (factorial(n - k) * factorial(k));
    }

    public List<Vector3f> BenzierCurve(List<Vector3f> titikYangAda) {
        List<Vector3f> listTitikBenzier = new ArrayList<>();

        // looping t nya
        for (float t = 0; t <= 1; t = t + 0.01f) {
            float hasilX = 0.0f;
            float hasilY = 0.0f;
            float hasilZ = 0.0f;

            int n = titikYangAda.size() - 1;

            // cari y dengan cara pakai rumus segitiga pascal (looping juga)
            // pakai kombinasi buat cari konstanta
            for (int polinom = 0; polinom <= n; polinom++) {
                // constanta * (1-t)^(n-polinom) * t^polinom * titikSekarang
                float perhitungan = koefisienPascal(n, polinom) * (float) (Math.pow(1 - t, n - polinom) * Math.pow(t, polinom));

                hasilX = hasilX + (titikYangAda.get(polinom).x * perhitungan);
                hasilY = hasilY + (titikYangAda.get(polinom).y * perhitungan);
                hasilZ = hasilZ + (titikYangAda.get(polinom).z * perhitungan);
            }

            // masukin dalam list
            listTitikBenzier.add(new Vector3f(hasilX, hasilY, hasilZ));
        }
        return listTitikBenzier;
    }

    public void createEllipticParaboloid() {
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for (double v = 0; v <= 100; v += 0.2) {
            for (double u = -Math.PI; u <= Math.PI; u += Math.PI / 120) {
                float x = 0.2f * (float) (v * Math.cos(u));
                float y = 0.2f * (float) ((v * Math.sin(u)));
                float z = 0.2f * (float) (Math.pow(v, 2));
                temp.add(new Vector3f(x, z, y));
            }
        }
        vertices = temp;
    }

    public void createHyperboloidParaboloid() {
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for (double v = 0; v <= 50; v += 0.2) {
            for (double u = -Math.PI; u <= Math.PI; u += Math.PI / 60) {
                float x = 0.2f * (float) (v * Math.tan(u));
                float y = 0.2f * (float) ((v * 1 / Math.cos(u)));
                float z = 0.2f * (float) (Math.pow(v, 2));
                temp.add(new Vector3f(x, y, z));
            }
        }
        vertices = temp;
    }

//    public void draw()
//    {
//        drawSetup();
//        glLineWidth(10); //ketebalan garis
//        glPointSize(10); //besar kecil vertex
//        glDrawArrays(GL_LINE_STRIP,
//                0,
//                vertices.size());
//    }
}
