package Engine.Angie;

import Engine.*;
import org.joml.Vector3f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

import static org.lwjgl.opengl.GL20.GL_FRAGMENT_SHADER;
import static org.lwjgl.opengl.GL20.GL_VERTEX_SHADER;

public class Blaze{

    // body
    Parts blazePart;
    float size;
    List<Float> centerPoint1;
    List<Vector3f> listRing;

    boolean notMove;

    Balls bolaTembak;

    public Blaze(List<Float> centerPoint, float size) {
        this.size = size;
        this.centerPoint1 = makeDuplicate(centerPoint);
        this.listRing = new ArrayList<>();
        this.notMove = false;
        makeParts();
    }

    public Parts getBlazePart() {
        return blazePart;
    }

    public float getSize() {
        return size;
    }

    public List<Float> getCenterPoint() {
        return centerPoint1;
    }

    private void makeParts() {
        System.out.println("coba : " + centerPoint1.get(0) + " " + centerPoint1.get(1) + " " + centerPoint1.get(2));
        // kepala jadi parent
        blazePart = new Parts(
                Arrays.asList(
                        // shaderfile lokasi menyeseuaikan objectnya
                        new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                Arrays.asList(), // warna kosongin
                makeDuplicate(centerPoint1),
                size, 0
        );
        System.out.println();


        // buat titik untuk 3 titik pusat lingkaran
        makeRings();
        System.out.println("sout list ring " + listRing.get(0).x + listRing.get(1).x + listRing.get(2).x);

        // buat baloknya
        // pake rumus lingkaran buat nentuin tp balok

        // array list
        List<ObjectKu> listBody = new ArrayList<>();
        // >> RING 1 , nentuin jari dengan size kubus juga <<
        float jari = size; // soalnya keluar kobus = 1/2 size + 1/2 size untuk luar lagi

        // depan z = 0
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(0).x,
                                listRing.get(0).y,
                                listRing.get(0).z
                        ),
                        size, 1
                )
        );
        int counter = 0;
        // perlu translasi ke depan dimana z = 0, dan posisi awal z diubah
        listBody.get(counter).translateObject(0.0f,0.0f, jari);


        // belakang z = 0
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(0).x,
                                listRing.get(0).y,
                                listRing.get(0).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke belakang
        listBody.get(counter).translateObject(0.0f,0.0f, -jari);


        // kiri
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(0).x,
                                listRing.get(0).y,
                                listRing.get(0).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke kanan
        listBody.get(counter).translateObject(-jari,0.0f, 0.0f);


        // kanan x
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(0).x,
                                listRing.get(0).y,
                                listRing.get(0).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke kanan
        listBody.get(counter).translateObject(jari,0.0f, 0.0f);



        // >> RING 2, nentuin jari dengan size kubus juga <<
        jari = 3.0f* size/4.0f;

        // depan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(1).x,
                                listRing.get(1).y,
                                listRing.get(1).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke depan dimana z = 0, dan posisi awal z diubah
        listBody.get(counter).translateObject(0.0f,0.0f, jari);


        // belakang
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(1).x,
                                listRing.get(1).y,
                                listRing.get(1).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke belakang
        listBody.get(counter).translateObject(0.0f,0.0f, -jari);


        // kiri
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(1).x,
                                listRing.get(1).y,
                                listRing.get(1).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke kanan
        listBody.get(counter).translateObject(-jari,0.0f, 0.0f);


        // kanan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(1).x,
                                listRing.get(1).y,
                                listRing.get(1).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke kanan
        listBody.get(counter).translateObject(jari,0.0f, 0.0f);



        // >> RING 3, nentuin jari dengan size kubus juga <<
        jari = 1.0f* size/2.0f;

        // depan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(2).x,
                                listRing.get(2).y,
                                listRing.get(2).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke depan dimana z = 0, dan posisi awal z diubah
        listBody.get(counter).translateObject(0.0f,0.0f, jari);


        // belakang
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(2).x,
                                listRing.get(2).y,
                                listRing.get(2).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke belakang
        listBody.get(counter).translateObject(0.0f,0.0f, -jari);


        // kiri
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(2).x,
                                listRing.get(2).y,
                                listRing.get(2).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke kanan
        listBody.get(counter).translateObject(-jari,0.0f, 0.0f);


        // kanan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                listRing.get(2).x,
                                listRing.get(2).y,
                                listRing.get(2).z
                        ),
                        size, 1
                )
        );
        counter++;
        // perlu translasi ke kanan
        listBody.get(counter).translateObject(jari,0.0f, 0.0f);


        // buat mata
        // kotak hitam
        float sizeMata = size/8;
        // kiri
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                (centerPoint1.get(0) - (size/8.0f) ),
                                centerPoint1.get(1) ,
                                centerPoint1.get(2) + (size/2.0f) // karena nempel sisi depan
                        ),
                        sizeMata, 0
                )
        );

        // kanan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                (centerPoint1.get(0) + (size/8.0f) ),
                                centerPoint1.get(1)  ,
                                centerPoint1.get(2) + (size/2.0f) // karena nempel sisi depan
                        ),
                        sizeMata, 0
                )
        );

        // putih
        // kiri
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                (centerPoint1.get(0) - (size/8.0f) - sizeMata),
                                centerPoint1.get(1),
                                centerPoint1.get(2) + (size/2.0f) // karena nempel sisi depan
                        ),
                        sizeMata, 0
                )
        );

        // kanan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                (centerPoint1.get(0) + (size/8.0f) + sizeMata),
                                centerPoint1.get(1) ,
                                centerPoint1.get(2) + (size/2.0f) // karena nempel sisi depan
                        ),
                        sizeMata, 0
                )
        );

        // rahang / jaws
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                centerPoint1.get(0),
                                centerPoint1.get(1) - 3*size/8.0f, // turunin 1/4 soalnya tingginga 1/4size
                                centerPoint1.get(2) + size/4.0f  // karena nempel sisi depan
                        ),
                        size/2f, 2
                )
        );

        // refer
        blazePart.setChildObject(listBody);

        // sisi kiri kepala
        // telinga kiri
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                centerPoint1.get(0) + (1.5f*size), // buat maju
                                centerPoint1.get(1), // turunin 1/4 soalnya tingginga 1/4size
                                centerPoint1.get(2)-(2.5f*size)// karena nempel sisi depan
                        ),
                        size/32f, 3
                )
        );

        // sisi kanan kepala
        // telinga kanan
        listBody.add(
                new Parts(
                        Arrays.asList(
                                // shaderfile lokasi menyeseuaikan objectnya
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                                new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                        ),
                        new ArrayList<>(),
                        Arrays.asList(), // kosongin warnanya
                        Arrays.asList(
                                centerPoint1.get(0) + (1.5f*size), // buat maju
                                centerPoint1.get(1), // turunin 1/4 soalnya tingginga 1/4size
                                centerPoint1.get(2) - 0.8f*size // karena nempel sisi depan
                        ),
                        size/32f, 4
                )
        );


        //       <<>>
        // >> RENDER COLOR <<
        //       <<>>
        setAllPartColor();
        setupVAOVBOWithcColors();



    }


    // buat ring nya
    private void makeRings(){
        List<Vector3f> listRingBaru =  new ArrayList<>();
        listRingBaru.add(new Vector3f(centerPoint1.get(0), (centerPoint1.get(1)- size/2.0f), centerPoint1.get(2)) ); // ring 1
        listRingBaru.add(new Vector3f(centerPoint1.get(0), (centerPoint1.get(1) - size), centerPoint1.get(2))); // ring 2
        listRingBaru.add(new Vector3f(centerPoint1.get(0), (centerPoint1.get(1) - (3.0f*size/2.0f)) , centerPoint1.get(2))); // ring 3

        listRing = listRingBaru;
    }

    public void setupVAOVBOWithcColors(){
        blazePart.setupVAOVBOWithVerticesColor();

        // supaya render
        for (int i = 0; i < blazePart.getChildObject().size(); i++){
            blazePart.getChildObject().get(i).setupVAOVBOWithVerticesColor();
        }
    }


    // dupicate 1 color titik
    public ArrayList<Vector3f> make1ColorDuplicate(Vector3f warnaKu, int titik){
        ArrayList<Vector3f> listColor = new ArrayList<>();
        for (int i =1; i <= titik; i++){
            listColor.add(warnaKu);
        }

        return listColor;
    }

    public void renderHead(){
        ArrayList<Vector3f> listColor = new ArrayList<>();
        // 6, 7 , 10, 14
        // set warnanya (212,174,55) coklat bawah dan (227,214,84) kuning (percobaan 1 : (156,108,35) untuk coklat)
        for (int i =0; i <= 16; i++) {
            if (i == 2 || i == 3|| i == 6 || i == 7 || i == 10 ||i== 11 || i == 14 || i == 15) {
//                listColor.add(new Vector3f(156f / 255f, 108f/ 255f, 35f/ 255f));
                listColor.add(new Vector3f(212f / 255f, 174f/ 255f, 55f/ 255f));
            }
            else {
                listColor.add(new Vector3f(227f / 255f, 214f / 255f, 84f / 255f));
            }
        }

        blazePart.verticesColor = listColor;

    }

    // buat coloring blazenya
    public void setAllPartColor(){
        // kepala
        renderHead();

        // kakinya
        int countKaki = 12;
        for (int j =0; j <countKaki; j++){
            ArrayList<Vector3f> listColor = new ArrayList<>();
            // 6, 7 , 10, 14
            // set warnanya oranye =(255,142,2) , coklat  (156,108,35) untuk coklat)
            for (int i =0; i <= 16; i++) {
                if (i == 2 || i == 3|| i == 6 || i == 7 || i == 10 ||i== 11 || i == 14 || i == 15) {
                    listColor.add(new Vector3f(255f / 255f, 142f/ 255f, 2f/ 255f));
                }
                else {
                    listColor.add(new Vector3f(227f / 255f, 214f / 255f, 84f / 255f));
                }
            }

            blazePart.getChildObject().get(j).verticesColor = listColor;
        }

        // matanya
        for (int i= countKaki; i < 14; i++){
            // hitam
            blazePart.getChildObject().get(i).verticesColor = make1ColorDuplicate(new Vector3f(0,0,0), 16);
        }

        // matanya
        for (int i= 14; i < 16; i++){
            // hitam
            blazePart.getChildObject().get(i).verticesColor = make1ColorDuplicate(new Vector3f(255,255,255), 16);
        }

        // rahangnya 147,112,18
        blazePart.getChildObject().get(16).verticesColor = make1ColorDuplicate(new Vector3f(147/255f,122/255f,18/255f), blazePart.getChildObject().get(blazePart.getChildObject().size()-1).vertices.size());

        Random rdm = new Random();
        blazePart.getChildObject().get(16).verticesColor = new ArrayList<>();
        for (int i = 0; i < blazePart.getChildObject().get(blazePart.getChildObject().size()-1).vertices.size(); i++){
            int tipe = rdm.nextInt(3);

            // merah maroon 87,28,0
            if (tipe == 0){
                blazePart.getChildObject().get(16).verticesColor.add(new Vector3f(87/255f,28/255f,0/255f));
            }
            // burn amber rgb(110, 38, 14)
            else if (tipe == 1) {
                blazePart.getChildObject().get(16).verticesColor.add(new Vector3f(110/255f,38/255f,14/255f));
            }
            // orange rgb(204, 85, 0)
            else {
                blazePart.getChildObject().get(16).verticesColor.add(new Vector3f(204/255f,85/255f,0/255f) ) ;
            }
        }

        // buat cone kiri dan kanan
        for (int i = 17; i < 19; i++){
            System.out.println("i : " + i);
            int count = 0;
            ArrayList<Vector3f> listColor = new ArrayList<>();
            for (int j = 0; j < blazePart.getChildObject().get(i).vertices.size(); j++){
                if (count == 0){
                    listColor.add(new Vector3f(227f / 255f, 214f / 255f, 84f / 255f)); // kuning
                    count++;
                }
                else if (count == 1){
                    // 217, 173, 78
                    listColor.add(new Vector3f(255f / 255f, 219f / 255f, 0f / 255f)); // orange kuning
                    count = 0;
                }
//                else {
//                    count = 0;
//                    // 222, 167, 80
//                   listColor.add(new Vector3f(255f / 255f, 185f / 255f, 16f / 255f)); // orange
//                }
            }
            blazePart.getChildObject().get(i).verticesColor = listColor;
        }
    }

//    public void printSemua(){
//        // buat partnya
//        // kepala
//        System.out.println("Head");
//        blazePart.printdetailVerticel();
//
//        System.out.println("\n Legs");
//        for (int i = 0; i < blazePart.getChildObject().size(); i++){
//            if (blazePart.getChildObject() != null){
//                blazePart.getChildObject().get(i).printdetailVerticel();
//                System.out.println(blazePart.getChildObject().get(i).centerPoint);
//            }
//        }
//    }


    // draw
    public void drawParts(Camera camera, Projection projection){
        blazePart.draw(camera,projection);
    }

    public void drawWithColorsParts(Camera camera, Projection projection) {
        blazePart.drawWithColor(camera, projection);
        if (bolaTembak != null) {
            bolaTembak.drawWithColor(camera, projection);
        }
    }

    public List<Float> makeDuplicate (List<Float> listYangDiDuplicate){
        List<Float> listDuplicate = new ArrayList<>();

        for (int i = 0 ; i < listYangDiDuplicate.size(); i++){
            listDuplicate.add(listYangDiDuplicate.get(i));
        }
        return listDuplicate;
    }

    //    public List<Float> makeListVector (Vector3f  vector3f){
//        List<Float> listDuplicate = new ArrayList<>();
//
//        listDuplicate.add(vector3f.x);
//        listDuplicate.add(vector3f.y);
//        listDuplicate.add(vector3f.z);
//
//        return listDuplicate;
//    }
    // fungsi pembantu
    public void rotateHead(){
        // kepala
        Vector3f blazeHead = new Vector3f(centerPoint1.get(0), centerPoint1.get(1), centerPoint1.get(2));
        blazePart.translateSelfObject(-blazeHead.x, -blazeHead.y, -blazeHead.z);
        blazePart.rotateSelfObject((float) Math.toRadians(1f), 0.0f, 1.0f, 0.0f);
        blazePart.translateSelfObject(blazeHead.x, blazeHead.y, blazeHead.z);

        // mata babak penentuan apakah bisa wkwkwkwk
        for (int i = 12 ; i < blazePart.getChildObject().size(); i++) {
            Vector3f blazeEyes = new Vector3f(centerPoint1.get(0), centerPoint1.get(1), centerPoint1.get(2));
            blazePart.getChildObject().get(i).translateObject(-1 * blazeEyes.x, -1 * blazeEyes.y, -1 * blazeEyes.z);
            blazePart.getChildObject().get(i).rotateObject((float) Math.toRadians(1f), 0.0f, 1.0f, 0.0f);
            blazePart.getChildObject().get(i).translateObject(1 * blazeEyes.x, 1 * blazeEyes.y, 1 * blazeEyes.z);

        }
    }

    // fungsi move legsnya
    public void stand(){
        if (!notMove){
            int i = 0;
            Vector3f ring = listRing.get(0);
            for (; i <= 3; i++) {
                blazePart.getChildObject().get(i).translateObject(-1 * ring.x, -1 * ring.y, -1 * ring.z);
                blazePart.getChildObject().get(i).rotateObject((float) Math.toRadians(2.5f), 0.0f, 1.0f, 0.0f);
                blazePart.getChildObject().get(i).translateObject(1 * ring.x, 1 * ring.y, 1 * ring.z);
            }
            ring = listRing.get(1);
            for (; i <= 7; i++) {
                blazePart.getChildObject().get(i).translateObject(-1 * ring.x, -1 * ring.y, -1 * ring.z);
                blazePart.getChildObject().get(i).rotateObject((float) Math.toRadians(2f), 0.0f, -1.0f, 0.0f);
                blazePart.getChildObject().get(i).translateObject(1 * ring.x, 1 * ring.y, 1 * ring.z);
            }
            ring = listRing.get(2);
            for (; i <= 11; i++) {
                blazePart.getChildObject().get(i).translateObject(-1 * ring.x, -1 * ring.y, -1 * ring.z);
                blazePart.getChildObject().get(i).rotateObject((float) Math.toRadians(1f), 0.0f, 1.0f, 0.0f);
                blazePart.getChildObject().get(i).translateObject(1 * ring.x, 1 * ring.y, 1 * ring.z);
            }

            if (bolaTembak != null){
                bolaTembak.moveBalls();
                if (bolaTembak.checkerDistance == false){
                    System.out.println("masuk false");
                    // hilangkan bola tembak
                    bolaTembak = null;
                }
            }
        }
    }

    // fungsi move legsnya
    public void moveRight(){
        blazePart.translateObject(0.01f, 0f, 0.0f);
        setAllCenterPointPosition(0.01f, 0f , 0f);
    }

    public void moveLeft(){
        blazePart.translateObject(-0.01f, 0f, 0.0f);
        setAllCenterPointPosition(-0.01f, 0f , 0f);
    }

    public void moveUp(){
        blazePart.translateObject(0f, 0.01f, 0.0f);
        setAllCenterPointPosition(0, 0.01f , 0f);
    }

    public void moveDown(){
        blazePart.translateObject(0f, -0.01f, 0.0f);
        setAllCenterPointPosition(0, -0.01f , 0f);
    }

    public void moveBackWard(){
        blazePart.translateObject(0f, 0.0f, -0.01f);
        setAllCenterPointPosition(0f, 0.0f, -0.01f);
    }

    public void moveForward(){
        blazePart.translateObject(0f, 0.00f, 0.01f);
        setAllCenterPointPosition(0f, 0.00f, 0.01f);
    }

    public void setNotMove(){
        this.notMove = true;
    }

    public void setMove(){
        this.notMove = false;
    }
    public void setAllCenterPointPosition(float x, float y , float z){
        centerPoint1 = Arrays.asList (
                centerPoint1.get(0)+x,
                centerPoint1.get(1)+y,
                centerPoint1.get(2)+z
        );
        makeRings();

    }

    public void shoot(Vector3f titikTujuan){
        // misal ga ada bola maka tembak
        if(bolaTembak == null){
            bolaTembak = new Balls(
                    Arrays.asList(
                            // shaderfile lokasi menyeseuaikan objectnya
                            new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                            new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                    ),
                    new ArrayList<>(),
                    new ArrayList<>(),
                    Arrays.asList(centerPoint1.get(0), centerPoint1.get(1)+ (3/2f *size), centerPoint1.get(2)), // titik diatas kepala
                    size/3f
            );
//            bolaTembak.setCenterPointPosition();
            bolaTembak.setTitikTujuan(titikTujuan);
            System.out.println(bolaTembak.centerPoint.get(0) + " " + bolaTembak.centerPoint.get(1) + " "  + bolaTembak.centerPoint.get(2));
        }
    }
}
