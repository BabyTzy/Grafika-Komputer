package Engine.Angie;

import org.joml.Vector3f;
import org.joml.Vector4f;
import java.util.*;

public class Balls extends ObjectKu {
    float size;

    Vector3f titikTujuan;

    List<Float> positionNow;

    float speedX, speedY, speedZ;
    boolean checkerDistance;

    public Balls(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> verits, Vector4f color, List<Float> centerPoint, float size) {
        super(shaderModuleDataList, verits, color, centerPoint);
        this.size = size;
        setCenterPoint(centerPoint);
        positionNow = new ArrayList<>(centerPoint);

        createBalls();
        if (titikTujuan == null) {
            checkerDistance = false;
        }
        else {
            checkerDistance = true;
        }
    }

    public Balls(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> verits, List<Vector3f> verticelsColors, List<Float> centerPoint, float size) {
        super(shaderModuleDataList, verits, verticelsColors, centerPoint);
        this.size = size;
        setCenterPoint(centerPoint);
        positionNow = new ArrayList<>(centerPoint);

        createBalls();
        if (titikTujuan == null) {
            checkerDistance = false;
        }
        else {
            checkerDistance = true;
        }
    }


    public void setTitikTujuan(Vector3f titikTujuan) {
        if (checkerDistance == false) {
            this.titikTujuan = titikTujuan;
            int pembagianSpeed = 35;
            // setting juga kecepatan bola nembak
            speedX = (titikTujuan.x - centerPoint.get(0)) / pembagianSpeed;
            speedY = (titikTujuan.y - centerPoint.get(1)) / pembagianSpeed;
            speedZ = (titikTujuan.z - centerPoint.get(2)) / pembagianSpeed;
            System.out.println("speed : " + speedX + " " + speedY + " " + speedZ);
            checkerDistance = true;
            System.out.println("titik tujuan : " + titikTujuan.x + " " + titikTujuan.y + " " + titikTujuan.z);
        }
    }

    public void setCheckerDistance(boolean checkerDistance) {
        this.checkerDistance = checkerDistance;
    }

    public Vector3f getTitikTujuan() {
        return titikTujuan;
    }

    public boolean isCheckerDistance() {
        return checkerDistance;
    }

    public List<Float> getPositionNow() {
        return positionNow;
    }

    public void setPositionNow(List<Float> positionNow) {
        this.positionNow = positionNow;
    }

    public void createBalls(){
        ArrayList<Vector3f> temp = new ArrayList<>();
        for(double v = -Math.PI/2; v<= Math.PI/2; v+=Math.PI/360){
            for(double u = -Math.PI; u<= Math.PI; u+=Math.PI/360){
                float x = centerPoint.get(0) + (size * (float)(Math.cos(v) * Math.cos(u)));
                float y = centerPoint.get(1) + (size * (float)(Math.cos(v) * Math.sin(u)));
                float z = centerPoint.get(2) + (size * (float)(Math.sin(v)));
                temp.add(new Vector3f(x,y,z));
            }
        }
        System.out.println(temp.size());
        vertices = temp; // 1860
        // render balls nya
        renderBalls();
    }

    public void renderBalls(){
        Random rdm = new Random();
//        List<Vector3f> color = new ArrayList<>();
        List<Vector3f> listColor = new ArrayList<>();

        int i = 1;
        int o = 0;
        boolean checker = true;

        while (checker) {
            // proses render warna
            // o >= 0 && 0 <= 5 || o == 0
            if (o >= 0 && o <= 10 && o != 3 && o!=4){
                listColor.add(new Vector3f(66/255f, 66/255f, 66/255f)); // grey dark
                o++;
            }
            else if (o == 3){
                listColor.add(new Vector3f(255/255f, 89/255f, 9/255f)); // oren api (255,89,9)
                o++;
            }
            else if (o == 4){
                listColor.add(new Vector3f(255/255f, 0/255f, 0/255f)); // oren api (255,89,9)
                o++;
            }
            else {
                listColor.add(new Vector3f(148/255f, 0f/255f, 0f/255f)); // merah tua
                o = 0;
            }
            i++;

            if (i > vertices.size()){
                checker = false;
                break;
            }
        }
        verticesColor = List.copyOf(listColor);
        System.out.println("size warna : " + verticesColor.size());
        setupVAOVBOWithVerticesColor();
    }

    public void setCenterPointPosition(float x, float y , float z){
        centerPoint = Arrays.asList (
                centerPoint.get(0)+x,
                centerPoint.get(1)+y,
                centerPoint.get(2)+z
        );
        positionNow =  Arrays.asList(
                positionNow.get(0)+x,
                positionNow.get(1)+y,
                positionNow.get(2)+z
        );
    }


    // pergerakan
    public void moveBalls(){
        // misal ada baru gerak
        if (titikTujuan != null){
            translateObject(speedX, speedY, speedZ);
            setCenterPointPosition(speedX, speedY, speedZ);
            rotateBall();

            // cek apakah sudah sampai
            float besarX, besarY, besarZ;
            float kecilX, kecilY, kecilZ;

            if ((titikTujuan.x + speedX) >= (titikTujuan.x - speedX) ){
                besarX = titikTujuan.x + speedX;
                kecilX = titikTujuan.x - speedX;
            }
            else {
                besarX = titikTujuan.x - speedX;
                kecilX = titikTujuan.x + speedX;
            }

            if ((titikTujuan.y + speedY) >= (titikTujuan.y - speedY) ){
                besarY = titikTujuan.y + speedY;
                kecilY = titikTujuan.y - speedY;
            }
            else {
                besarY = titikTujuan.y - speedY;
                kecilY = titikTujuan.y + speedY;
            }

            if ((titikTujuan.z + speedZ) >= (titikTujuan.z - speedZ) ){
                besarZ = titikTujuan.z + speedZ;
                kecilZ = titikTujuan.z - speedZ;
            }
            else {
                besarZ = titikTujuan.z - speedZ;
                kecilZ = titikTujuan.z + speedZ;
            }

            if (positionNow.get(0) >= kecilX && positionNow.get(0) <= besarX && positionNow.get(1) >= kecilY && positionNow.get(1) <= besarY && positionNow.get(2) >= kecilZ && positionNow.get(2)<= besarZ){
                titikTujuan = null;
                checkerDistance = false;
            }
        }
    }

    // rotate ball terhadap diri sendiri (jaga2 di translasi)
    public void rotateBall(){
        Vector3f balls = new Vector3f(positionNow.get(0), positionNow.get(1), positionNow.get(2));
        translateObject(-balls.x, -balls.y, -balls.z);
        rotateObject((float) Math.toRadians(6f), 0.0f, 1.0f, 0.0f);
        translateObject(balls.x, balls.y, balls.z);
    }

    public void moveBallsUp(){
        float kecepatanNaik = 0.01f;
        translateObject(0.0f,kecepatanNaik,0.0f);
        setCenterPointPosition(0.0f, kecepatanNaik, 0.0f);
        rotateBall();
    }

}


