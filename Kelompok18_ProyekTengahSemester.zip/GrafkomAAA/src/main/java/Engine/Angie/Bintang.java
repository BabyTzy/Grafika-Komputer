package Engine.Angie;

import Engine.Anthony.Circle;
import Engine.Utils;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL15;

import java.util.List;

import static org.lwjgl.opengl.GL15.*;

public class Bintang extends Circle {
    List<Integer> index;
    int ibo;

    public Bintang(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> vertis, Vector4f color, float pX, float pY, float jari, int titik, List<Integer> index) {
        super(shaderModuleDataList, vertis, color, pX, pY, jari, titik);
        this.index = index;

        // set ibo (index buffer object || element buffer object)
        ibo = glGenBuffers();
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
        GL15.glBufferData(GL_ELEMENT_ARRAY_BUFFER, Utils.listoInt(this.index), GL_STATIC_DRAW);

    }

    public void draw() {
        drawSetup();

        // bind IBO and draw
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ibo);
        glDrawElements(GL_LINES, index.size(), GL_UNSIGNED_INT, 0);

        // yang bisa digambar : GL_LINE, GL_LINE STRIP, GL_LINE_LOOP, GL_TRIANGLE , GL_TRIANGLE_FAN , GL_POINT
    }

}