package Engine.Angie;

import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Parts extends ObjectKu {
    float size;

    public Parts(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> verits, Vector4f color, List<Float> centerPoint, float size, int tipe) {
        super(shaderModuleDataList, verits, color, centerPoint);
        this.size = size;

        if (tipe == 0){
            createCube();
        }
        else if (tipe == 2){
            createRahang();
        }
        else if (tipe == 1){
            createBox();
        }

        else if (tipe == 3){
            createConeLeft();
        }

        else if (tipe == 4){
            createConeRight();
        }

        setCenterPoint(centerPoint);
    }

    public Parts(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> verits, List<Vector3f> verticelsColors, List<Float> centerPoint, float size, int tipe) {
        super(shaderModuleDataList, verits, verticelsColors, centerPoint);
//        this.centerPoint = centerPoint;
        this.size = size;

        if (tipe == 0){
            createCube();
        }
        else if (tipe == 2){
            createRahang();
        }
        else if (tipe == 1){
            createBox();
        }

        else if (tipe == 3){
            createConeLeft();
        }

        else if (tipe == 4){
            createConeRight();
        }


        setCenterPoint(centerPoint);
    }

    // fungsi buat buat kubus dan balok
    // buat kepala
    public void createCube(){
        Vector3f temp = new Vector3f();
        ArrayList<Vector3f> tempVerticels = new ArrayList<>();

        int a = 0; // x
        int b = 1; // y
        int c = 2; // z

        // >> Kotak Belakang
        // titik 1
        temp.x = centerPoint.get(a) - size/2.0f;
        temp.y = centerPoint.get(b) + size/2.0f;
        temp.z = centerPoint.get(c) - size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 2
        temp.x = centerPoint.get(a) + size/2.0f;
        temp.y = centerPoint.get(b) + size/2.0f;
        temp.z = centerPoint.get(c) - size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 3
        temp.x = centerPoint.get(a) + size/2.0f;
        temp.y = centerPoint.get(b) - size/2.0f;
        temp.z = centerPoint.get(c) - size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 4
        temp.x = centerPoint.get(a) - size/2.0f;
        temp.y = centerPoint.get(b) - size/2.0f;
        temp.z = centerPoint.get(c) - size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();


        // >> kotak depan
        // titik 1
        temp.x = centerPoint.get(a) - size/2.0f;
        temp.y = centerPoint.get(b) + size/2.0f;
        temp.z = centerPoint.get(c) + size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 2
        temp.x = centerPoint.get(a) + size/2.0f;
        temp.y = centerPoint.get(b) + size/2.0f;
        temp.z = centerPoint.get(c) + size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 3
        temp.x = centerPoint.get(a) + size/2.0f;
        temp.y = centerPoint.get(b) - size/2.0f;
        temp.z = centerPoint.get(c) + size/2.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 4
        temp.x = centerPoint.get(a) - size/2.0f;
        temp.y = centerPoint.get(b) - size/2.0f;
        temp.z = centerPoint.get(c) + size/2.0f;

        tempVerticels.add(temp);

        // clear dulu verticelsnya
        vertices.clear();

        // kotak belakang
        vertices.add(tempVerticels.get(0));
        vertices.add(tempVerticels.get(1));
        vertices.add(tempVerticels.get(2));
        vertices.add(tempVerticels.get(3));

        // kotak depan
        vertices.add(tempVerticels.get(4));
        vertices.add(tempVerticels.get(5));
        vertices.add(tempVerticels.get(6));
        vertices.add(tempVerticels.get(7));

        // kotak samping kiri
        vertices.add(tempVerticels.get(0));
        vertices.add(tempVerticels.get(4));
        vertices.add(tempVerticels.get(7));
        vertices.add(tempVerticels.get(3));

        // kotak samping kanan
        vertices.add(tempVerticels.get(1));
        vertices.add(tempVerticels.get(5));
        vertices.add(tempVerticels.get(6));
        vertices.add(tempVerticels.get(2));

    }

    // buat kaki batang
    public void createBox(){
        Vector3f temp = new Vector3f();
        ArrayList<Vector3f> tempVerticels = new ArrayList<>();
//        System.out.println("centerpoint balok : " + centerPoint.get(0) + " " + centerPoint.get(1) + " " + centerPoint.get(2));


        // >> Kotak Belakang
        // titik 1
        temp.x = centerPoint.get(0) - size /8.0f;
        temp.y = centerPoint.get(1) + size /2.0f;
        temp.z = centerPoint.get(2) - size /8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 2
        temp.x = centerPoint.get(0) + size/8.0f;
        temp.y = centerPoint.get(1) + size/2.0f;
        temp.z = centerPoint.get(2) - size/8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 3
        temp.x = centerPoint.get(0) + size/8.0f;
        temp.y = centerPoint.get(1) - size/2.0f;
        temp.z = centerPoint.get(2) - size/8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 4
        temp.x = centerPoint.get(0) - size/8.0f;
        temp.y = centerPoint.get(1) - size/2.0f;
        temp.z = centerPoint.get(2) - size/8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();


        // >> kotak depan
        // titik 1
        temp.x = centerPoint.get(0) - size/8.0f;
        temp.y = centerPoint.get(1) + size/2.0f;
        temp.z = centerPoint.get(2) + size/8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 2
        temp.x = centerPoint.get(0) + size/8.0f;
        temp.y = centerPoint.get(1) + size/2.0f;
        temp.z = centerPoint.get(2) + size/8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 3
        temp.x = centerPoint.get(0) + size/8.0f;
        temp.y = centerPoint.get(1) - size/2.0f;
        temp.z = centerPoint.get(2) + size/8.0f;

        tempVerticels.add(temp);
        temp = new Vector3f();

        // titik 4
        temp.x = centerPoint.get(0) - size/8.0f;
        temp.y = centerPoint.get(1) - size/2.0f;
        temp.z = centerPoint.get(2) + size/8.0f;

        tempVerticels.add(temp);

        // clear dulu verticelsnya
        vertices.clear();

        // kotak belakang
        vertices.add(tempVerticels.get(0)); // 0
        vertices.add(tempVerticels.get(1)); // 1
        vertices.add(tempVerticels.get(2)); // 2
        vertices.add(tempVerticels.get(3)); // 3

        // kotak depan
        vertices.add(tempVerticels.get(4)); // 4
        vertices.add(tempVerticels.get(5)); // 5
        vertices.add(tempVerticels.get(6)); // 6
        vertices.add(tempVerticels.get(7)); // 7

        // kotak samping kiri
        vertices.add(tempVerticels.get(0)); // 8
        vertices.add(tempVerticels.get(4)); // 9
        vertices.add(tempVerticels.get(7)); // 10
        vertices.add(tempVerticels.get(3)); // 11

        // kotak samping kanan
        vertices.add(tempVerticels.get(1)); // 12
        vertices.add(tempVerticels.get(5)); // 13
        vertices.add(tempVerticels.get(6)); // 14
        vertices.add(tempVerticels.get(2)); // 15
    }

    public void createRahang(){
        Vector3f temp = new Vector3f();
        ArrayList<Vector3f> tempVerticels = new ArrayList<>();
        int a = 0;
        int b = 1;
        int c = 2;

        // buat kotak depan dulu
        // >> kotak depan
        // titik 1 kiri atas
        float perbesaranX = 1.1f;
        temp.x = centerPoint.get(a) - (perbesaranX * size);
        temp.y = centerPoint.get(b) + size/4.0f;
        temp.z = centerPoint.get(c) + size/2.0f;

        tempVerticels.add(temp);

        temp = new Vector3f();
        // titik 2 kanan atas
        temp.x = centerPoint.get(a) + (perbesaranX * size);
        temp.y = centerPoint.get(b) + size/4.0f;
        temp.z = centerPoint.get(c) + size/2.0f;

        tempVerticels.add(temp);

        temp = new Vector3f();
        // titik 3 kanan bawah
        temp.x = centerPoint.get(a) + (perbesaranX * size);
        temp.y = centerPoint.get(b) - size/4.0f;
        temp.z = centerPoint.get(c) + size/2.0f;
        tempVerticels.add(temp);

        temp = new Vector3f();
        // titik 4 kiri bawah
        temp.x = centerPoint.get(a) - (perbesaranX * size);
        temp.y = centerPoint.get(b) - size/4.0f;
        temp.z = centerPoint.get(c) + size/2.0f;
        tempVerticels.add(temp);

        temp = new Vector3f();
        // kotak bawah
        // titik 5 kiri bawah belakang
        temp.x = centerPoint.get(a) - (perbesaranX * size);
        temp.y = centerPoint.get(b) - size/4.0f;
        temp.z = centerPoint.get(c) - size/2.0f;
        tempVerticels.add(temp);

        temp = new Vector3f();
        // titik 6 kanan bawah belakang
        temp.x = centerPoint.get(a) +(perbesaranX * size);
        temp.y = centerPoint.get(b) - size/4.0f;
        temp.z = centerPoint.get(c) - size/2.0f;
        tempVerticels.add(temp);

        // clear dulu verticelsnya
        vertices.clear();

        // >> ADD
        //nambahin kotaknya dulu
        // kotak depan
        vertices.add(tempVerticels.get(0)); // 0
        vertices.add(tempVerticels.get(1)); // 1
        vertices.add(tempVerticels.get(2)); // 2
        vertices.add(tempVerticels.get(3)); // 3

        // kotak bawah
        // kotak depan
        vertices.add(tempVerticels.get(4)); // 4
        vertices.add(tempVerticels.get(5)); // 5
        vertices.add(tempVerticels.get(2)); // 2
        vertices.add(tempVerticels.get(3)); // 3

        System.out.println("verticel : " + vertices.size());

        // sekarang benzier
        // kanan
        List<Vector3f> listKurvaKanan = BenzierCurve(Arrays.asList(tempVerticels.get(1), tempVerticels.get(2), tempVerticels.get(5))); //1,2,5

        // kiri
        List<Vector3f> listKurvaKiri= BenzierCurve(Arrays.asList(tempVerticels.get(0), tempVerticels.get(3), tempVerticels.get(4))); //0,3,4

        // gambar benziernya
        // kanan
        for(int i = 0; i < listKurvaKanan.size()-2; i++){
            // titik kurva dulu
            vertices.add(listKurvaKanan.get(i));
            vertices.add(listKurvaKanan.get(i+1));
            vertices.add(listKurvaKanan.get(i+2));
            vertices.add(tempVerticels.get(2));
        }

        // kiri
        for(int i = 0; i < listKurvaKiri.size()-2; i++){
            // titik kurva dulu
            vertices.add(listKurvaKiri.get(i));
            vertices.add(listKurvaKiri.get(i+1));
            vertices.add(listKurvaKiri.get(i+2));
            vertices.add(tempVerticels.get(3));
        }

        // layer atas
        for (int i = 0; i < listKurvaKiri.size()-1; i++){
            // titik kurva kiri kanan
            vertices.add(listKurvaKiri.get(i));
            vertices.add(listKurvaKiri.get(i+1));
            vertices.add(listKurvaKanan.get(i));
            vertices.add(listKurvaKanan.get(i+1));

        }
        System.out.println("size tipe 2:" +vertices.size());
    }


    public void createConeRight(){
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for(double v = 0; v<= 2 * Math.PI; v+=Math.PI/60){
            for(double u = -Math.PI; u<= Math.PI; u+=Math.PI/60){
                float x = centerPoint.get(0) - (float) (size * v * Math.cos(u)/2*Math.PI);
                float y = centerPoint.get(1) - (float)  (size * v * Math.sin(u)/2*Math.PI);
                float z = centerPoint.get(2) - (float) ((size * v) /2*Math.PI);
                temp.add(new Vector3f(z,y,x)); // kekanan pakai
            }
        }
        vertices = temp;
    }

    public void createConeLeft(){
        vertices.clear();
        ArrayList<Vector3f> temp = new ArrayList<>();

        for(double v = 0; v<= 2 * Math.PI; v+=Math.PI/60){
            for(double u = -Math.PI; u<= Math.PI; u+=Math.PI/60){
                float x = centerPoint.get(0) -  (float) (size * v * Math.cos(u)/2*Math.PI);
                float y = centerPoint.get(1) - (float)  (size * v * Math.sin(u)/2*Math.PI);
                float z = centerPoint.get(2) - (float) ((size * v) /2*Math.PI);
                temp.add(new Vector3f(-z,y,x)); // kekanan pakai
            }
        }
        vertices = temp;
    }



    // fungsi bantu buat bezier (sumber bantuan resource lama)
    public int factorial(int angka){
        if (angka == 0) {
            return 1;
        }

        int hasil = 1;
        for (int i = 2; i <= angka; i++){
            hasil = hasil * i;
        }

        return hasil;
    }

    // buat cari koef segitiga pascal
    public int koefisienPascal(int n , int k){
        return factorial(n)/(factorial(n-k)*factorial(k));
    }

    public List<Vector3f> BenzierCurve(List<Vector3f> titikYangAda){
        List<Vector3f> listTitikBenzier = new ArrayList<>();

        // looping t nya
        for (float t = 0; t <= 1; t = t + 0.01f){
            float hasilX = 0.0f;
            float hasilY = 0.0f;
            float hasilZ = 0.0f;

            int n = titikYangAda.size()-1;

            // cari y dengan cara pakai rumus segitiga pascal (looping juga)
            // pakai kombinasi buat cari konstanta
            for (int polinom = 0; polinom <= n; polinom++) {
                // constanta * (1-t)^(n-polinom) * t^polinom * titikSekarang
                float perhitungan = koefisienPascal(n, polinom) * (float) (Math.pow(1-t, n-polinom) * Math.pow(t, polinom) );

                hasilX = hasilX + (titikYangAda.get(polinom).x * perhitungan );
                hasilY = hasilY + (titikYangAda.get(polinom).y * perhitungan );
                hasilZ = hasilZ + (titikYangAda.get(polinom).z * perhitungan );
            }

            // masukin dalam list
            listTitikBenzier.add(new Vector3f(hasilX, hasilY, hasilZ));
        }
        return listTitikBenzier;
    }
}
