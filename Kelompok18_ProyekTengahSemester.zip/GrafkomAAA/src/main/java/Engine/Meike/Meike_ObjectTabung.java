package Engine.Meike;

import Engine.Camera;
import Engine.Projection;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

import static org.lwjgl.opengl.GL11.*;

public class Meike_ObjectTabung extends Meike_Circle {
    float height;
    int stackCount;
    int sectorCount;

    public Meike_ObjectTabung(List<ShaderModuleData> shaderModuleDataList, List<Vector3f> vertices, Vector4f color, List<Float> centerPoint, Float radiusX, Float radiusY, Float height,
                              int sectorCount, int stackCount) {
        super(shaderModuleDataList, vertices, color, centerPoint, radiusX, radiusY);
        this.stackCount = stackCount;
        this.sectorCount = sectorCount;
        this.height = height;
        createTabung();
        setupVAOVBO();
    }

    public void createTabung() {
        ArrayList<Vector3f> sphereVertices = new ArrayList<>();

        float pi = (float) Math.PI;

        float sectorStep = 2 * pi / sectorCount;
        float stackStep = height / stackCount;
        float sectorAngle, stackAngle;
        float x, y, z;

        for (int i = 0; i <= stackCount; ++i) {
            stackAngle = i * stackStep;
            x = radiusX;
            y = radiusY;
            z = stackAngle;

            for (int j = 0; j <= sectorCount; ++j) {
                sectorAngle = j * sectorStep;
                Vector3f tempVector = new Vector3f();

                tempVector.x = centerPoint.get(0) + x * (float) Math.cos(sectorAngle);
                tempVector.y = centerPoint.get(1) + y * (float) Math.sin(sectorAngle);
                tempVector.z = centerPoint.get(2) + z;
                sphereVertices.add(tempVector);
            }
        }
        vertices = sphereVertices;
    }

    public void draw(Camera camera, Projection projection) {
        drawSetup(camera, projection);
        glLineWidth(0); //Ketebalan garis
        glPointSize(0); //Besar kecil vertex
        glDrawArrays(GL_TRIANGLE_FAN, 0, vertices.size());
    }
}
