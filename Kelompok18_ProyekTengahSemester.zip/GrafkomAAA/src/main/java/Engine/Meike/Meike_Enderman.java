package Engine.Meike;

import Engine.ShaderProgram;

import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.lwjgl.opengl.GL20.GL_FRAGMENT_SHADER;
import static org.lwjgl.opengl.GL20.GL_VERTEX_SHADER;

public class Meike_Enderman {
    public void generateEnderman(ArrayList<Meike_Object> objects, List<Float> titikPusat, float xGeser, float yGeser) {
        //KEPALA ENDERMAN (get(0))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.5f, 0.5f, 0.5f, 36, 18
        ));
        //Mengecilkan Kepala Enderman Karena Scaling
        objects.get(0).scaleObject(0.5f, 0.5f, 0.5f);

        //Memposisikan Kepala Enderman di bagian bagian 0.5f dari Y
        objects.get(0).translate(0.0f + xGeser, 0.5f + yGeser, 0.0f);

        //BADAN ENDERMAN (get(1))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.5f, 0.65f, 0.5f, 36, 18
        ));
        //Mengecilkan Badan Enderman Karena Scaling
        objects.get(1).scaleObject(0.5f, 0.5f, 0.5f);

        //Memposisikan Badan Enderman di bagian bagian 0.215f dari Y
        objects.get(1).translate(0.0f + xGeser, 0.215f + yGeser, 0.0f);

        //KAKI KANAN ENDERMAN (get(2))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.1f, 0.8f, 0.1f, 36, 18
        ));
        //Mengecilkan Kaki Kanan Enderman Karena Scaling
        objects.get(2).scaleObject(0.5f, 0.5f, 0.5f);

        //Memposisikan Kaki Kanan Enderman di bagian bagian 0.05f dari X dan -0.15 dari Y
        objects.get(2).translate(0.05f + xGeser, -0.145f + yGeser, 0.0f);

        //KAKI KIRI ENDERMAN (get(3))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.1f, 0.8f, 0.1f, 36, 18
        ));
        //Mengecilkan Kaki Kiri Enderman Karena Scaling
        objects.get(3).scaleObject(0.5f, 0.5f, 0.5f);

        //Memposisikan Kaki Kanan Enderman di bagian bagian -0.05f dari X dan -0.15 dari Y
        objects.get(3).translate(-0.05f + xGeser, -0.145f + yGeser, 0.0f);

        //MATA KANAN ENDERMAN (get(4))
        objects.add(new Meike_ObjectBola(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 255 / 255, (float) 255 / 255, 0.0f),
                titikPusat,
                0.05f, 0.05f, 0.05f, 36, 18
        ));
        objects.get(4).scaleObject(0.05f, 0.05f, 0.05f);

        objects.get(4).translate(0.05f + xGeser, 0.55f + yGeser, 0.08f);

        //MATA KIRI ENDERMAN (get(5))
        objects.add(new Meike_ObjectBola(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 255 / 255, (float) 255 / 255, 0.0f),
                titikPusat,
                0.05f, 0.05f, 0.05f, 36, 18
        ));
        objects.get(5).scaleObject(0.05f, 0.05f, 0.05f);

        objects.get(5).translate(-0.05f + xGeser, 0.55f + yGeser, 0.08f);

        //BOLA MATA KANAN (get(6))
        objects.add(new Meike_ObjectBola(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 168 / 255, (float) 255 / 255, 0.0f),
                titikPusat,
                0.01f, 0.01f, 0.01f, 36, 18
        ));
        objects.get(6).scaleObject(0.03f, 0.03f, 0.05f);

        objects.get(6).translate(0.057f + xGeser, 0.555f + yGeser, 0.1f);

        //BOLA MATA KIRI (get(7))
        objects.add(new Meike_ObjectBola(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 168 / 255, (float) 255 / 255, 0.0f),
                titikPusat,
                0.01f, 0.01f, 0.01f, 36, 18
        ));
        objects.get(7).scaleObject(0.03f, 0.03f, 0.05f);

        objects.get(7).translate(-0.044f + xGeser, 0.555f + yGeser, 0.1f);

        //HALO (Enderman) (get(8))
        objects.add(new Meike_ObjectBola(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 255 / 255, (float) 102 / 255, 0.0f),
                titikPusat,
                0.01f, 0.01f, 0.01f, 36, 18
        ));
        objects.get(8).scaleObject(0.03f, 0.03f, 0.05f);

        objects.get(8).translate(0.0f + xGeser, 0.65f + yGeser, 0.2f);

        //TANGAN KANAN ENDERMAN (get(9))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.1f, 0.8f, 0.1f, 36, 18
        ));
        objects.get(9).scaleObject(0.5f, 0.5f, 0.5f);

        objects.get(9).translate(0.145f + xGeser, 0.177f + yGeser, 0.0f);

        //TANGAN KIRI ENDERMAN (get(10))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.1f, 0.8f, 0.1f, 36, 18
        ));
        objects.get(10).scaleObject(0.5f, 0.5f, 0.5f);

        objects.get(10).translate(-0.145f + xGeser, 0.177f + yGeser, 0.0f);

        //RAMBUT ENDERMEN SEBELAH KIRI (get(11)) --> RAMBUT UPIN/JAMET
        objects.add(new Meike_Bezier(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                Arrays.asList(
                        new Vector3f(0.02f, 0.1f, 0.0f),
                        new Vector3f(0.1f, 0.3f, 0.0f),
                        new Vector3f(0.25f, 0.15f, 0.0f),
                        new Vector3f(0.3f, 0.3f, 0.0f))
        ));
        objects.get(11).translate(-0.14f + xGeser, 0.527f + yGeser, 0.00f);

        //RAMBUT ENDERMEN SEBELAH KANAN (get(12)) --> RAMBUT UPIN/JAMET
        objects.add(new Meike_Bezier(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                Arrays.asList(
                        new Vector3f(0.265f, 0.1f, 0.0f),
                        new Vector3f(0.3f, 0.2f, 0.0f),
                        new Vector3f(0.3f, 0.25f, 0.0f),
                        new Vector3f(0.3f, 0.3f, 0.0f))
        ));
        objects.get(12).translate(-0.14f + xGeser, 0.527f + yGeser, 0.0f);

        //RAMBUT BAWAH ENDERMAN (get(13))
        objects.add(new Meike_Bezier(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                Arrays.asList(
                        new Vector3f(0.0f, 0.0f, 0.0f),
                        new Vector3f(0.2f, 0.2f, 0.0f),
                        new Vector3f(0.4f, 0.0f, 0.0f),
                        new Vector3f(0.5f, 0.2f, 0.0f))
        ));
        objects.get(13).scaleObject(0.5f, 0.5f, 0.5f);

        objects.get(13).translate(0.0f + xGeser, 0.05f + yGeser, 0.0f);

        objects.get(13).rotateObjects(90f, 0.5f, -0.5f, 0.0f);

        //MULUT ENDERMAN (get(14))
        objects.add(new Meike_Bezier(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 255 / 255, (float) 255 / 255, 0.0f),
                Arrays.asList(
                        new Vector3f(-0.05f, 0.3f, 0.0f),
                        new Vector3f(-0.025f, 0.25f, 0.0f),
                        new Vector3f(0.0f, 0.35f, 0.0f),
                        new Vector3f(0.025f, 0.25f, 0.0f),
                        new Vector3f(0.05f, 0.3f, 0.0f))
        ));
        objects.get(14).translate(0.0f + xGeser, 0.2f + yGeser, 0.1f);

        //PIVOT POINT KAKI KANAN ENDERMAN (get(15))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.05f, 0.05f, 0.05f, 36, 18
        ));
        objects.get(15).scaleObject(0.055f, 0.05f, 0.05f);

        objects.get(15).translate(0.05f + xGeser, 0.05f + yGeser, 0.0f);

        //PIVOT POINT KAKI KIRI ENDERMAN (get(16))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.05f, 0.05f, 0.05f, 36, 18
        ));
        objects.get(16).scaleObject(0.055f, 0.05f, 0.05f);

        objects.get(16).translate(-0.05f + xGeser, 0.05f + yGeser, 0.0f);

        //PIVOT POINT TANGAN KANAN ENDERMAN (get(17))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.05f, 0.05f, 0.05f, 36, 18
        ));
        objects.get(17).scaleObject(0.05f, 0.05f, 0.05f);

        objects.get(17).translate(0.145f + xGeser, 0.377f + yGeser, 0.3f);

        //PIVOT POINT TANGAN KIRI ENDERMAN (get(19))
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.05f, 0.05f, 0.05f, 36, 18
        ));
        objects.get(18).scaleObject(0.05f, 0.05f, 0.05f);

        objects.get(18).translate(-0.5f + xGeser, 0.377f + yGeser, 0.3f);

        //TOPI (get(19))
        objects.add(new Meike_ObjectTabung(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 153 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                titikPusat,
                0.8f, 0.5f, 0.5f, 36, 18
        ));
        objects.get(19).scaleObject(0.3f, 0.3f, 0.3f);

        //Y jd Z nya
        objects.get(19).translate(0.0f + xGeser, 0.05f, 0.635f + yGeser);

        objects.get(19).rotate(1.5f, -1.0f, 0.0f, 0.0f);
    }

    public void generateLatar(ArrayList<Meike_Object> objects) {
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 128 / 255, (float) 255 / 255, (float) 0 / 255, 0.0f),
                Arrays.asList(0.0f, 0.0f, 0.0f),
                5.0f, 0.2f, 5.0f, 36, 18
        ));
        objects.get(20).scaleObject(1.0f, 1.0f, 1.0f);

        objects.get(20).translate(0.0f, -0.45f, 0.0f);
    }

    public void generateBox(ArrayList<Meike_Object> objects) {
        objects.add(new Meike_ObjectKubus(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 153 / 255, (float) 0 / 255, (float) 0 / 255, 0.0f),
                Arrays.asList(objects.get(1).getPos().x, objects.get(1).getPos().y - 0.2f, objects.get(1).getPos().z + 0.3f),
                0.25f, 0.25f, 0.25f, 36, 18
        ));
        objects.get(21).scaleObject(0.1f, 0.1f, 0.1f);
        objects.get(21).translate(0.0f, 0.5f, 0.0f);
    }

    public void removeBox(ArrayList<Meike_Object> objects) {
        objects.remove(21);
    }
}