import Engine.*;
import Engine.Angie.Balls;
import Engine.Angie.Blaze;
import Engine.Anthony.*;
import Engine.Anthony.Object;
import Engine.Meike.*;
import Engine.Samantha.BezierSamantha;
import Engine.Samantha.ObjectSamantha;
import Engine.Samantha.SphereSamantha;
import org.joml.Vector3f;
import org.joml.Vector4f;
import org.lwjgl.opengl.GL;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static org.lwjgl.glfw.GLFW.*;
import static org.lwjgl.opengl.GL30.*;

public class Main {
    private Window window = new Window(1920, 1080, "PROYEK GRAFKOM KELOMPOK 18");

    ArrayList<Vector3f> points = new ArrayList<>();

    //Meike
    public ArrayList<Meike_Object> meike_object = new ArrayList<>();
    Meike_Enderman meike_enderman = new Meike_Enderman();

    //Samantha
    private ArrayList<ObjectSamantha> objectSamantha = new ArrayList<>();
    private int step = 0;
    int countDegree = 0;
    float size = 0.3f; //Size Utama

    boolean maju = true;
    float stepSpeed;
    boolean setSpeed = false; //Blm Jalan

    final float xPindahPosVil = 1.0f;
    final float yPindahPosVil = 0.5f;

    //Angie
    public ArrayList<Blaze> objectBlaze = new ArrayList<>();
    public ArrayList<Balls> objectBalls = new ArrayList<>();
    private ArrayList<Object2d> objectsRectangle = new ArrayList<>();
    ArrayList<Object2d> objectsFromCircle = new ArrayList<>();
    ArrayList<Object> object = new ArrayList<>();

    private ArrayList<Object2d> objectsPointsControl = new ArrayList<>();
    private Object coba;
    Projection projection = new Projection(window.getWidth(), window.getHeight());
    Camera camera = new Camera();
    private ArrayList<Object2d> Kotak = new ArrayList<>();


    public List<Vector3f> makeVector3fCircle(float pusatX, float pusatY, float jari, int titik) {
        List<Vector3f> listVerticelCircle = new ArrayList<>();

        float pi = 3.14f;
        float incTetha = 360f / titik;

        // posisi awal
        for (int i = 0; i < titik; i++) {
            float x = (float) (pusatX + 1.0f * jari * Math.cos(i * incTetha / 180.0f * pi));
            float y = (float) (pusatY + 1.0f * jari * Math.sin(i * incTetha / 180.0f * pi));

            // masukan ke dalam list verticels
            System.out.println(x + " " + y);
            listVerticelCircle.add(new Vector3f(x, y, 0));
        }
        return listVerticelCircle;
    }

    public void init() {
        window.init();
        GL.createCapabilities();

        camera.setPosition(0.0f, 0.0f, 2.5f);
        camera.setRotation((float) Math.toRadians(0.0f), (float) Math.toRadians(0.0f));

        final float xGhast = -0.6f;
        final float yGhast = 2.5f;
        final float zGhast = -1.5f;
        //Pala ghast

        //Obj 0
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(0.0f + xGhast, 0.0f + yGhast, 0.0f + zGhast),
                0.5f,
                0.5f,
                0.5f, 9, 18, 7
        ));
        //mata kiri
        //Obj 1
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.0f, 0.0f, 0.0f, 0.0f),
                Arrays.asList(-0.1f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.1f,
                0.03f,
                0.11f, 9, 18, 7
        ));
        //mata kanan
        //Obj 2
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.0f, 0.0f, 0.0f, 0.0f),
                Arrays.asList(0.1f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.1f,
                0.03f,
                0.11f, 9, 18, 7
        ));
        //mulut
        //Obj 3
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.0f, 0.0f, 0.0f, 0.0f),
                Arrays.asList(0.0f + xGhast, -0.15f + yGhast, 0.2f + zGhast),
                0.2f,
                0.03f,
                0.11f, 9, 18, 7
        ));
        //kaki1
        //Obj 4
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(0.0f + xGhast, -0.35f + yGhast, 0.13f + zGhast),
                0.06f,
                0.21f,
                0.08f, 9, 18, 7
        ));

        //kaki2
        //Obj 5
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(0.1f + xGhast, -0.35f + yGhast, 0.13f + zGhast),
                0.06f,
                0.3f,
                0.08f, 9, 18, 7
        ));

        //kaki3
        //Obj 6
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(-0.1f + xGhast, -0.35f + yGhast, 0.13f + zGhast),
                0.06f,
                0.28f,
                0.08f, 9, 18, 7
        ));

        //kaki tengah
        //Obj 7
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(0.0f + xGhast, -0.35f + yGhast, 0.0f + zGhast),
                0.06f,
                0.28f,
                0.08f, 9, 18, 7
        ));

        //kaki 4
        //Obj 8
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(

                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(-0.1f + xGhast, -0.35f + yGhast, -0.13f + zGhast),
                0.06f,
                0.35f,
                0.08f, 9, 18, 7
        ));

        //kaki 5
        //Obj 9
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(0.0f + xGhast, -0.35f + yGhast, -0.13f + zGhast),
                0.06f,
                0.27f,
                0.08f, 9, 18, 7
        ));

        //kaki 6
        //Obj 10
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(0.82f, 0.82f, 0.82f, 0.0f),
                Arrays.asList(0.1f + xGhast, -0.35f + yGhast, -0.13f + zGhast),
                0.06f,
                0.29f,
                0.08f, 9, 18, 7
        ));

        //Telinga kanan
        //Obj 11
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(0.0f, 1.0f, 0.0f, 0.0f),
                Arrays.asList(0.33f + xGhast, 0.1f + yGhast, 0.0f + zGhast),
                0.05f,
                0.1f,
                0.2f, 27, 45, 1
        ));
        //Telinga Kiri
        //Obj 12
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(0.0f, 1.0f, 0.0f, 0.0f),
                Arrays.asList(-0.33f + xGhast, 0.1f + yGhast, 0.0f + zGhast),
                0.05f,
                0.1f,
                0.2f, 27, 45, 1
        ));
        //frame kacamata atas kiri
        //Obj 13
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(-0.1f + xGhast, 0.15f + yGhast, 0.2f + zGhast),
                0.15f,
                0.015f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata bawah kiri
        //Obj 14
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(-0.1f + xGhast, 0.05f + yGhast, 0.2f + zGhast),
                0.15f,
                0.02f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata atas kanan
        //Obj 15
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(0.1f + xGhast, 0.15f + yGhast, 0.2f + zGhast),
                0.15f,
                0.015f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata bawah kanan
        //Obj 16
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(0.1f + xGhast, 0.05f + yGhast, 0.2f + zGhast),
                0.15f,
                0.015f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata kiri kiri
        //Obj 17
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(-0.17f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.015f,
                0.087f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata kiri kanan
        //Obj 18
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(-0.03f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.015f,
                0.087f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata kanan kiri
        //Obj 19
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(0.03f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.015f,
                0.087f,
                0.11f, 9, 18, 7
        ));

        //frame kacamata kanan kanan
        //Obj 20
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(0.17f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.015f,
                0.087f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata tengah
        //Obj 21
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(0.0f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.08f,
                0.015f,
                0.11f, 9, 18, 7
        ));
        //frame kacamata pipi kanan
        //Obj 22
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(0.21f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.095f,
                0.015f,
                0.1f, 9, 18, 7
        ));
        //frame kacamata pipi kiri
        //Obj 23
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of(
                        )),
                new Vector4f(1.0f, 0.84f, 0.0f, 0.0f),
                Arrays.asList(-0.21f + xGhast, 0.1f + yGhast, 0.2f + zGhast),
                0.095f,
                0.015f,
                0.1f, 9, 18, 7
        ));

        //coba benzier
        object.add(new Benzier(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 0 / 255, (float) 255 / 255, (float) 0 / 255, 0.0f),
                Arrays.asList(
                        new Vector3f(-0.335f + xGhast, 0.0f + yGhast, 0.0f),
                        new Vector3f(-0.235f + xGhast, 0.65f + yGhast, 0.0f),
                        new Vector3f(0.235f + xGhast, 0.65f + yGhast, 0.0f),
                        new Vector3f(0.335f + xGhast, 0.0f + yGhast, 0.0f))
        ));
        object.get(24).translateObject(0.0f, 0.0f, 0.0f + zGhast);

        final float xAwan = 0.0f;
        final float yAwan = 1.0f;
        //coba awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.9f, 0.6f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.8f, 0.6f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.7f, 0.6f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.6f, 0.6f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.85f, 0.7f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.75f, 0.7f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.85f, 0.5f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.75f, 0.5f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.65f, 0.5f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));
        //Awan
        object.add(new Sphere(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData(
                                "resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(
                        List.of()
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 0.0f),
                Arrays.asList(-0.65f, 0.7f + yAwan, 0.0f),
                0.1f,
                0.1f,
                0.2f, 27, 45, 0
        ));

    //MEIKE SURAJIMAN - C14210116 - ENDERMAN
        meike_enderman.generateEnderman(meike_object, Arrays.asList(0.0f, 0.0f, 0.0f), -0.9f, 0.0f);
        meike_enderman.generateLatar(meike_object);

    //KEYSHA ANGIE - C14210115 - BLAZE
        objectBlaze.add(new Blaze(
                Arrays.asList(1.5f, 2.5f, -1.5f), // titik pusat kepala
                0.6f
        ));

        // >>>>> BALLS <<<<<<
        objectBalls.add(new Balls(
                Arrays.asList(
                        // shaderfile lokasi menyeseuaikan objectnya
                        new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/sceneModelWithColor.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new ArrayList<>(),
                Arrays.asList(-1.5f, -1.0f, 1.0f), // titik pusat kepala
                0.2f
        ));

    //SAMANTHA E CHEN - C14210049 - VILLAGER
        //kepala (0)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(158 / 255f, 104 / 255f, 32 / 255f, 1.0f),
                Arrays.asList(0.0f + xPindahPosVil, 0.0f + yPindahPosVil, 0.0f),
                size, //ukuran besarnya
                size + size / 3,
                size,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //mata ijo kiri (1)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(0, 153 / 255f, 0, 1.0f),
                Arrays.asList((0.0f - size / 8 - (size / 8) / 2) + xPindahPosVil, (0.0f - size / 8 - (size + size / 3) / 8 + ((size + size / 3) / 8) / 2) + yPindahPosVil, 0.0f + size / 2),
                size / 8,
                size / 8,
                size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //mata ijo kanan (2)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(0, 153 / 255f, 0, 1.0f),
                Arrays.asList((0.0f + size / 8 + (size / 8) / 2) + xPindahPosVil, (0.0f - size / 8 - (size + size / 3) / 8 + ((size + size / 3) / 8) / 2) + yPindahPosVil, 0.0f + size / 2),
                size / 8,
                size / 8,
                size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //mata putih kiri (3)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(1, 255 / 255f, 1, 1.0f),
                Arrays.asList((0.0f - size / 8 - size / 8 - (size / 8) / 2) + xPindahPosVil, (0.0f - size / 8 - (size + size / 3) / 8 + ((size + size / 3) / 8) / 2) + yPindahPosVil, 0.0f + size / 2),
                size / 8,
                size / 8,
                size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //mata putih kanan (4)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(1, 255 / 255f, 1, 1.0f),
                Arrays.asList((0.0f + size / 8 + size / 8 + (size / 8) / 2) + xPindahPosVil, (0.0f - size / 8 - (size + size / 3) / 8 + ((size + size / 3) / 8) / 2) + yPindahPosVil, 0.0f + size / 2),
                size / 8,
                size / 8,
                size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //alis (5)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(0 / 255f, 0 / 255f, 0 / 255f, 1.0f),
                Arrays.asList(0.0f + xPindahPosVil, (0.0f - (size / 8) / 2) + yPindahPosVil, 0.0f + size / 2),
                6 * size / 8,
                size / 8,
                size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //mulut (6)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(102 / 255f, 51 / 255f, 0 / 255f, 1.0f),
                Arrays.asList(0.0f + xPindahPosVil, (0.0f - 3 * size / 8 - (size / 8) / 2) + yPindahPosVil, 0.0f + size / 2),
                4 * size / 8,
                size / 8,
                size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //idung (7)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(153 / 255f, 76 / 255f, 0 / 255f, 1.0f),
                Arrays.asList(0.0f + xPindahPosVil, (0.0f - 4 * size / 8 - (size / 8) / 2) + yPindahPosVil, 0.0f + size / 1.8f),
                size / 6,
                1.5f * size / 4,
                size / 6,
                36, //buat 36 kolom dan 18 baris
                18,
                1
        ));

        //badan (8)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(78 / 255f, 31 / 255f, 11 / 255f, 1.0f),
                Arrays.asList(0.0f + xPindahPosVil, (0.0f - size - size / 3) + yPindahPosVil, 0.0f),
                size - size / 8, //ukuran besarnya
                size + size / 2,
                size - size / 8, // 7/8 size
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //kaki kiri (9)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(32 / 255f, 32 / 255f, 32 / 255f, 1.0f),
                Arrays.asList((0.0f - ((size - size / 8) / 2) / 2) + xPindahPosVil, (0.0f - size / 2 - (size + size / 2) - (size / 1.5f) / 2) + yPindahPosVil, 0.0f), //letaknya x di 0.0 dikurangi size kaki/2
                (size - size / 8) / 2, //ukuran besarnya kaki
                size / 1.5f,
                size - size / 8 - size / 4, // 5/8 size
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //kaki kanan (10)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(32 / 255f, 32 / 255f, 32 / 255f, 1.0f),
                Arrays.asList((0.0f + ((size - size / 8) / 2) / 2) + xPindahPosVil, (0.0f - size / 2 - (size + size / 2) - (size / 1.5f) / 2) + yPindahPosVil, 0.0f), //letaknya x di 0.0 dikurangi size kaki/2
                (size - size / 8) / 2, //ukuran besarnya kaki
                size / 1.5f,
                size - size / 8 - size / 4,
                36, //buat 36 kolom dan 18 baris
                18,
                0
        ));

        //tangan kanan (11)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(104 / 255f, 43 / 255f, 17 / 255f, 1.0f),
                Arrays.asList((0.0f - (size - size / 8) / 2) + xPindahPosVil, (0.0f - size - size / 3) + yPindahPosVil, 0.0f + (size - size / 8) / 3), //posisi z dikedepankan
                size - size / 8, //ukuran besarnya
                size / 2.5f,
                size - size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                2
        ));

        //tangan kiri (12)
        objectSamantha.add(new SphereSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),
                new Vector4f(104 / 255f, 43 / 255f, 17 / 255f, 1.0f),
                Arrays.asList((0.0f + (size - size / 8) / 2) + xPindahPosVil, (0.0f - size - size / 3) + yPindahPosVil, 0.0f + (size - size / 8) / 3), //posisi z dikedepankan
                size - size / 8, //ukuran besarnya
                size / 2.5f,
                size - size / 8,
                36, //buat 36 kolom dan 18 baris
                18,
                2
        ));

        //rambut villager (13)
        objectSamantha.add(new BezierSamantha(
                Arrays.asList(
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)
                ),
                new ArrayList<>(),

                new Vector4f((float) 255 / 255, (float) 255 / 255, (float) 255 / 255, 0.0f),
                Arrays.asList(
                        new Vector3f(0.0f, 0.0f, 0.0f),
                        new Vector3f(0.1f, 0.2f, 0.0f),
                        new Vector3f(0.3f, 0.0f, 0.0f),
                        new Vector3f(0.3f, 0.2f, 0.0f))
        ));
        objectSamantha.get(13).translateObject(0.0f + xPindahPosVil, 0.2f + yPindahPosVil, 0.0f);
    }

    public int factorial(int angka) {
        if (angka == 0) {
            return 1;
        }

        int hasil = 1;
        for (int i = 2; i <= angka; i++) {
            hasil = hasil * i;
        }

        return hasil;
    }

    // buat cari koef segitiga pascal
    public int koefisienPascal(int n, int k) {
        return factorial(n) / (factorial(n - k) * factorial(k));
    }

    public List<Vector3f> BenzierCurve(List<Vector3f> titikYangAda) {
        List<Vector3f> listTitikBenzier = new ArrayList<>();

        // looping t nya
        for (float t = 0; t <= 1; t = t + 0.01f) {
            float hasilX = 0.0f;
            float hasilY = 0.0f;
            float hasilZ = 0.0f;

            int n = titikYangAda.size() - 1;

            // cari y dengan cara pakai rumus segitiga pascal (looping juga)
            // pakai kombinasi buat cari konstanta
            for (int polinom = 0; polinom <= n; polinom++) {
                // constanta * (1-t)^(n-polinom) * t^polinom * titikSekarang
                float perhitungan = koefisienPascal(n, polinom) * (float) (Math.pow(1 - t, n - polinom) * Math.pow(t, polinom));

                hasilX = hasilX + (titikYangAda.get(polinom).x * perhitungan);
                hasilY = hasilY + (titikYangAda.get(polinom).y * perhitungan);
                hasilZ = hasilZ + (titikYangAda.get(polinom).z * perhitungan);
            }

            // masukin dalam list
            listTitikBenzier.add(new Vector3f(hasilX, hasilY, hasilZ));
        }
        return listTitikBenzier;
    }

    public Rectangle buatKotak(float pX, float pY) {
        float size = 0.05f;
        Vector3f k1 = new Vector3f(1f * pX - size, 1f * pY + size, 0);
        Vector3f k2 = new Vector3f(1f * pX - size, 1f * pY - size, 0);
        Vector3f k3 = new Vector3f(1f * pX + size, 1f * pY + size, 0);
        Vector3f k4 = new Vector3f(1f * pX + size, 1f * pY - size, 0);

        Rectangle Kotak = new Rectangle(
                Arrays.asList(new ShaderProgram.ShaderModuleData("resources/shaders/scene.vert", GL_VERTEX_SHADER),
                        new ShaderProgram.ShaderModuleData("resources/shaders/scene.frag", GL_FRAGMENT_SHADER)),
                new ArrayList<>(
                        List.of(k1, k2, k3, k4)
                ),
                new Vector4f(1.0f, 1.0f, 1.0f, 1.0f),
                Arrays.asList(0, 1, 2, 1, 2, 3));
        return Kotak;
    }

    public void loop() {
        while (window.isOpen()) {
            window.update();
            glClearColor(0.0f, 1.0f, 1.0f, 0.0f);
            GL.createCapabilities();
            input();


            //code
            /* for(Object2d object: objects){
                object.drawWithVerticesColor();
            } */
            for (Object2d object : objectsRectangle) {
                object.draw();  // draw rectangle
            }
//            for (Object2d object : objectCircle){
//                object.draw(); // draw lingkaran

//            }
            for (Object2d object : objectsFromCircle) {
                object.draw();
            }
//            for(Object2d object: objectsPointsControl){
//                object.drawCurve(points);
//            }
            for (Object object : object) {
                object.draw(camera, projection);
            }
            for (Meike_Object object : meike_object) {
                object.draw(camera, projection);
            }
            for (ObjectSamantha object : objectSamantha) {
                object.draw(camera, projection);
            }

            // Blaze
            objectBlaze.get(0).stand();
            for (Blaze object : objectBlaze) {
                object.drawWithColorsParts(camera, projection);

            }
            for (Balls object : objectBalls) {
                object.drawWithColor(camera, projection);
            }
//            for (Object objectBenzier : objectBenzier){
//                object.drawLine(camera, projection);
//            }

//            for(Object2d object: objectsPointsControl){
//                object.drawLine(); // draw garis kontrol
//            }
            for (Object2d object : Kotak) {
                object.draw(); // draw kotak
            }
            input();
            //restore state
            glDisableVertexAttribArray(0);

            //poll for windows events
            //the key callback aboce will only be invoked during this call
            glfwPollEvents();
        }

    }

    public void run() {
        init();
        loop();

        glfwTerminate();
        glfwSetErrorCallback(null).free();
    }

    public static void main(String[] args) {
        new Main().run();
        //System.out.println("Hello World");
    }


    //fungsi INput dari mouse
    boolean cek = false;
    boolean drag = false;
    int noHold = 0;
    int counter = 0;
    rumusDariCircle temp;

    public void input() {
        rumusDariCircle h;

        List<ShaderProgram.ShaderModuleData> shader = Arrays.asList(
                //shaderFile lokasi menyesuaikan objectnya
                new ShaderProgram.ShaderModuleData
                        ("resources/shaders/scene.vert"
                                , GL_VERTEX_SHADER),
                new ShaderProgram.ShaderModuleData
                        ("resources/shaders/scene.frag"
                                , GL_FRAGMENT_SHADER)
        );

        //PUNYA ANGIE
        // gerak ke kanan (x)
        if (window.isKeyPressed(GLFW_KEY_P)) {
            System.out.println();
            objectBlaze.get(0).moveRight();
        }

        // gerak naik
        if (window.isKeyPressed(GLFW_KEY_B)) {
            System.out.println();
            objectBlaze.get(0).moveUp();
        }
        // nembak sesuai bola
        if (window.isKeyPressed(GLFW_KEY_O)) {
            objectBlaze.get(0).shoot(new Vector3f(objectBalls.get(0).getPositionNow().get(0), objectBalls.get(0).getPositionNow().get(1), objectBalls.get(0).getPositionNow().get(2)));
        }

        // move balls
        if (window.isKeyPressed(GLFW_KEY_U)) {
            objectBalls.get(0).moveBallsUp();
        }

        //Punya meike
        //ANIMASI GERAK JALAN
        //W jadi 1
        if (window.isKeyPressed(GLFW_KEY_1)) {
            if (Math.abs(meike_object.get(3).getPos().y - (-0.12)) < 0.000001f) {
                return;
            }

            //KAKI KIRI
            Vector3f posisiKakiKiri = meike_object.get(15).getPos();
            meike_object.get(3).rotasiIkutPoros(0.01f, 1.0f, 0.0f, 0.0f, posisiKakiKiri);

            //TANGAN KANAN
            Vector3f posisiTanganKanan = meike_object.get(17).getPos();
            meike_object.get(9).rotasiIkutPoros(0.01f, 1.0f, 0.0f, 0.0f, posisiTanganKanan);

            //KAKI KANAN
            Vector3f posisiKakiKanan = meike_object.get(16).getPos();
            meike_object.get(2).rotasiIkutPoros(0.01f, -1.0f, 0.0f, 0.0f, posisiKakiKanan);

            //TANGAN KIRI
            Vector3f posisiTanganKiri = meike_object.get(18).getPos();
            meike_object.get(10).rotasiIkutPoros(0.01f, -2.0f, 0.0f, 0.0f, posisiTanganKiri);

            meike_object.get(0).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(1).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(2).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(3).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(4).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(5).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(6).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(7).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(8).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(9).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(10).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(11).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(12).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(13).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(14).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(15).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(16).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(17).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(18).translate(-0.01f, 0.0f, 0.0f);
            meike_object.get(19).translate(-0.01f, 0.0f, 0.0f);
        }
        //S jadi 2
        if (window.isKeyPressed(GLFW_KEY_2)) {
            System.out.println(meike_object.get(2).getPos().x + " " + meike_object.get(2).getPos().y);
            if (Math.abs(meike_object.get(2).getPos().y - (-0.12)) < 0.000001f) {
                return;
            }
            //KAKI KIRI
            Vector3f posisiKakiKiri = meike_object.get(15).getPos();
            meike_object.get(3).rotasiIkutPoros(0.01f, -1.0f, 0.0f, 0.0f, posisiKakiKiri);

            //TANGAN KANAN
            Vector3f posisiTanganKanan = meike_object.get(17).getPos();
            meike_object.get(9).rotasiIkutPoros(0.01f, -2.0f, 0.0f, 0.0f, posisiTanganKanan);

            //KAKI KANAN
            Vector3f posisiKakiKanan = meike_object.get(16).getPos();
            meike_object.get(2).rotasiIkutPoros(0.01f, 1.0f, 0.0f, 0.0f, posisiKakiKanan);

            //TANGAN KIRI
            Vector3f posisiTanganKiri = meike_object.get(18).getPos();
            meike_object.get(10).rotasiIkutPoros(0.01f, 1.0f, 0.0f, 0.0f, posisiTanganKiri);

            meike_object.get(0).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(1).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(2).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(3).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(4).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(5).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(6).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(7).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(8).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(9).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(10).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(11).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(12).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(13).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(14).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(15).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(16).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(17).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(18).translate(0.01f, 0.0f, 0.0f);
            meike_object.get(19).translate(0.01f, 0.0f, 0.0f);
        }
        //G jadi 3
        if (window.isKeyPressed(GLFW_KEY_3)) {
            for (Meike_Object object : meike_object) {
                object.rotateObjects(0.01f, 0f, 0.1f, 0f);
            }
        }
        //H jadi 4
        if (window.isKeyPressed(GLFW_KEY_4)) {
            Vector3f posisiKepala = meike_object.get(0).getPos();
            meike_object.get(8).rotasiIkutPoros(0.01f, 0.0f, 1f, 0.0f, posisiKepala);
        }
        //L jadi 5
        if (window.isKeyPressed(GLFW_KEY_5)) {
            Vector3f posisiMataKanan = meike_object.get(4).getPos();
            meike_object.get(6).rotasiIkutPoros(0.01f, 0.0f, 0.0f, 1f, posisiMataKanan);
        }
        //K jadi 6
        if (window.isKeyPressed(GLFW_KEY_6)) {
            Vector3f posisiMataKiri = meike_object.get(5).getPos();
            meike_object.get(7).rotasiIkutPoros(0.01f, 0.0f, 0.0f, 1f, posisiMataKiri);
        }
        //F jadi 7
        if (window.isKeyPressed(GLFW_KEY_7)) {
            meike_enderman.generateBox(meike_object);
        }
        //C jadi 8
        if (window.isKeyPressed(GLFW_KEY_8)) {
            meike_enderman.removeBox(meike_object);
        }
        // setting camera

        if (window.isKeyPressed(GLFW_KEY_UP)) {
            camera.moveUp(0.01f);
        }

        if (window.isKeyPressed(GLFW_KEY_DOWN)) {
            camera.moveDown(0.01f);
        }
        if (window.isKeyPressed(GLFW_KEY_LEFT)) {
            camera.moveLeft(0.01f);

        }
        if (window.isKeyPressed(GLFW_KEY_RIGHT)) {
            camera.moveRight(0.01f);
        }

        if (window.isKeyPressed(GLFW_KEY_Q)) {
            camera.moveForward(0.01f);
        }
        if (window.isKeyPressed(GLFW_KEY_E)) {
            camera.moveBackwards(0.01f);
        }
        if (window.isKeyPressed(GLFW_KEY_S)) {
            camera.addRotation(-0.01f, 0.0f);
        }
        if (window.isKeyPressed(GLFW_KEY_W)) {
            camera.addRotation(0.01f, 0.0f);
        }
        if (window.isKeyPressed(GLFW_KEY_A)) {
            camera.addRotation(0.00f, 0.01f);
        }
        if (window.isKeyPressed(GLFW_KEY_D)) {
            camera.addRotation(0.00f, -0.01f);
        }
        //muter"
        if (window.isKeyPressed(GLFW_KEY_G)) {
            object.get(0).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);

            object.get(1).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(2).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(3).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(4).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(5).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(6).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(7).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(8).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(9).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(10).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(11).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//telinga kanan
            object.get(12).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//telinga kiri
            object.get(13).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(14).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(15).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(16).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);///Kacamata
            object.get(17).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);
            object.get(18).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(19).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(20).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(21).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(22).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(23).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);//Kacamata
            object.get(24).rotateObject((float) Math.toRadians(0.5f), 0.0f, 1.0f, 0.0f);


        }

        //Bikin kaki ubur" nya gerak
        if (window.isKeyPressed(GLFW_KEY_H)) {
            object.get(4).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(5).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(6).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(7).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(8).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(9).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(10).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);

        }
        //bikin kaki ubur" nya gerak juga
        if (window.isKeyPressed(GLFW_KEY_C)) {
            object.get(4).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(5).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(6).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(7).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(8).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(9).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(10).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
        }
        //Naik
        if (window.isKeyPressed(GLFW_KEY_I)) {
            object.get(0).translateObject(0.0f, 0.01f, 0.0f);
            object.get(1).translateObject(0.0f, 0.01f, 0.0f);
            object.get(2).translateObject(0.0f, 0.01f, 0.0f);
            object.get(3).translateObject(0.0f, 0.01f, 0.0f);
            object.get(4).translateObject(0.0f, 0.01f, 0.0f);
            object.get(5).translateObject(0.0f, 0.01f, 0.0f);
            object.get(6).translateObject(0.0f, 0.01f, 0.0f);
            object.get(7).translateObject(0.0f, 0.01f, 0.0f);
            object.get(8).translateObject(0.0f, 0.01f, 0.0f);
            object.get(9).translateObject(0.0f, 0.01f, 0.0f);
            object.get(10).translateObject(0.0f, 0.01f, 0.0f);
            object.get(11).translateObject(0.0f, 0.01f, 0.0f);
            object.get(12).translateObject(0.0f, 0.01f, 0.0f);
            object.get(13).translateObject(0.0f, 0.01f, 0.0f);
            object.get(14).translateObject(0.0f, 0.01f, 0.0f);
            object.get(15).translateObject(0.0f, 0.01f, 0.0f);
            object.get(16).translateObject(0.0f, 0.01f, 0.0f);
            object.get(17).translateObject(0.0f, 0.01f, 0.0f);
            object.get(18).translateObject(0.0f, 0.01f, 0.0f);
            object.get(19).translateObject(0.0f, 0.01f, 0.0f);
            object.get(20).translateObject(0.0f, 0.01f, 0.0f);
            object.get(21).translateObject(0.0f, 0.01f, 0.0f);
            object.get(22).translateObject(0.0f, 0.01f, 0.0f);
            object.get(23).translateObject(0.0f, 0.01f, 0.0f);
            object.get(24).translateObject(0.0f, 0.01f, 0.0f);
            System.out.println("J");
        }
        //turun
        if (window.isKeyPressed(GLFW_KEY_K)) {
            object.get(0).translateObject(0.0f, -0.01f, 0.0f);
            object.get(1).translateObject(0.0f, -0.01f, 0.0f);
            object.get(2).translateObject(0.0f, -0.01f, 0.0f);
            object.get(3).translateObject(0.0f, -0.01f, 0.0f);
            object.get(4).translateObject(0.0f, -0.01f, 0.0f);
            object.get(5).translateObject(0.0f, -0.01f, 0.0f);
            object.get(6).translateObject(0.0f, -0.01f, 0.0f);
            object.get(7).translateObject(0.0f, -0.01f, 0.0f);
            object.get(8).translateObject(0.0f, -0.01f, 0.0f);
            object.get(9).translateObject(0.0f, -0.01f, 0.0f);
            object.get(10).translateObject(0.0f, -0.01f, 0.0f);
            object.get(11).translateObject(0.0f, -0.01f, 0.0f);
            object.get(12).translateObject(0.0f, -0.01f, 0.0f);
            object.get(13).translateObject(0.0f, -0.01f, 0.0f);
            object.get(14).translateObject(0.0f, -0.01f, 0.0f);
            object.get(15).translateObject(0.0f, -0.01f, 0.0f);
            object.get(16).translateObject(0.0f, -0.01f, 0.0f);
            object.get(17).translateObject(0.0f, -0.01f, 0.0f);
            object.get(18).translateObject(0.0f, -0.01f, 0.0f);
            object.get(19).translateObject(0.0f, -0.01f, 0.0f);
            object.get(20).translateObject(0.0f, -0.01f, 0.0f);
            object.get(21).translateObject(0.0f, -0.01f, 0.0f);
            object.get(22).translateObject(0.0f, -0.01f, 0.0f);
            object.get(23).translateObject(0.0f, -0.01f, 0.0f);
            object.get(24).translateObject(0.0f, -0.01f, 0.0f);

            System.out.println("K");
        }
        //ghast gerak ke kiri
        if (window.isKeyPressed(GLFW_KEY_J)) {
            object.get(0).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(1).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(2).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(3).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(4).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(5).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(6).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(7).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(8).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(9).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(10).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(11).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(12).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(13).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(14).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(15).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(16).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(17).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(18).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(19).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(20).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(21).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(22).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(23).translateObject(-0.01f, 0.0f, 0.0f);
            object.get(24).translateObject(-0.01f, 0.0f, 0.0f);

            System.out.println("J");
        }
        //gerak ke kanan
        if (window.isKeyPressed(GLFW_KEY_L)) {
            object.get(0).translateObject(0.01f, 0.0f, 0.0f);
            object.get(1).translateObject(0.01f, 0.0f, 0.0f);
            object.get(2).translateObject(0.01f, 0.0f, 0.0f);
            object.get(3).translateObject(0.01f, 0.0f, 0.0f);
            object.get(4).translateObject(0.01f, 0.0f, 0.0f);
            object.get(5).translateObject(0.01f, 0.0f, 0.0f);
            object.get(6).translateObject(0.01f, 0.0f, 0.0f);
            object.get(7).translateObject(0.01f, 0.0f, 0.0f);
            object.get(8).translateObject(0.01f, 0.0f, 0.0f);
            object.get(9).translateObject(0.01f, 0.0f, 0.0f);
            object.get(10).translateObject(0.01f, 0.0f, 0.0f);
            object.get(11).translateObject(0.01f, 0.0f, 0.0f);
            object.get(12).translateObject(0.01f, 0.0f, 0.0f);
            object.get(13).translateObject(0.01f, 0.0f, 0.0f);
            object.get(14).translateObject(0.01f, 0.0f, 0.0f);
            object.get(15).translateObject(0.01f, 0.0f, 0.0f);
            object.get(16).translateObject(0.01f, 0.0f, 0.0f);
            object.get(17).translateObject(0.01f, 0.0f, 0.0f);
            object.get(18).translateObject(0.01f, 0.0f, 0.0f);
            object.get(19).translateObject(0.01f, 0.0f, 0.0f);
            object.get(20).translateObject(0.01f, 0.0f, 0.0f);
            object.get(21).translateObject(0.01f, 0.0f, 0.0f);
            object.get(22).translateObject(0.01f, 0.0f, 0.0f);
            object.get(23).translateObject(0.01f, 0.0f, 0.0f);
            object.get(24).translateObject(0.01f, 0.0f, 0.0f);

            System.out.println("L");
        }
        //Bikin ghastnya maju
        if (window.isKeyPressed(GLFW_KEY_Z)) {
            object.get(0).translateObject(0.0f, 0.0f, 0.01f);
            object.get(1).translateObject(0.0f, 0.0f, 0.01f);
            object.get(2).translateObject(0.0f, 0.0f, 0.01f);
            object.get(3).translateObject(0.0f, 0.0f, 0.01f);
            object.get(4).translateObject(0.0f, 0.0f, 0.01f);
            object.get(5).translateObject(0.0f, 0.0f, 0.01f);
            object.get(6).translateObject(0.0f, 0.0f, 0.01f);
            object.get(7).translateObject(0.0f, 0.0f, 0.01f);
            object.get(8).translateObject(0.0f, 0.0f, 0.01f);
            object.get(9).translateObject(0.0f, 0.0f, 0.01f);
            object.get(10).translateObject(0.0f, 0.0f, 0.01f);
            object.get(11).translateObject(0.0f, 0.0f, 0.01f);
            object.get(12).translateObject(0.0f, 0.0f, 0.01f);
            object.get(13).translateObject(0.0f, 0.0f, 0.01f);
            object.get(14).translateObject(0.0f, 0.0f, 0.01f);
            object.get(15).translateObject(0.0f, 0.0f, 0.01f);
            object.get(16).translateObject(0.0f, 0.0f, 0.01f);
            object.get(17).translateObject(0.0f, 0.0f, 0.01f);
            object.get(18).translateObject(0.0f, 0.0f, 0.01f);
            object.get(19).translateObject(0.0f, 0.0f, 0.01f);
            object.get(20).translateObject(0.0f, 0.0f, 0.01f);
            object.get(21).translateObject(0.0f, 0.0f, 0.01f);
            object.get(22).translateObject(0.0f, 0.0f, 0.01f);
            object.get(23).translateObject(0.0f, 0.0f, 0.01f);
            object.get(24).translateObject(0.0f, 0.0f, 0.01f);
            object.get(4).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(5).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(6).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(7).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(8).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(9).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            object.get(10).rotateObject((float) Math.toRadians(0.3f), -0.0625f, 0.0f, 0.0f);
            System.out.println("L");
        }
        //Bikin ghastnya mundur
        if (window.isKeyPressed(GLFW_KEY_X)) {
            object.get(0).translateObject(0.0f, 0.0f, -0.01f);
            object.get(1).translateObject(0.0f, 0.0f, -0.01f);
            object.get(2).translateObject(0.0f, 0.0f, -0.01f);
            object.get(3).translateObject(0.0f, 0.0f, -0.01f);
            object.get(4).translateObject(0.0f, 0.0f, -0.01f);
            object.get(5).translateObject(0.0f, 0.0f, -0.01f);
            object.get(6).translateObject(0.0f, 0.0f, -0.01f);
            object.get(7).translateObject(0.0f, 0.0f, -0.01f);
            object.get(8).translateObject(0.0f, 0.0f, -0.01f);
            object.get(9).translateObject(0.0f, 0.0f, -0.01f);
            object.get(10).translateObject(0.0f, 0.0f, -0.01f);
            object.get(11).translateObject(0.0f, 0.0f, -0.01f);
            object.get(12).translateObject(0.0f, 0.0f, -0.01f);
            object.get(13).translateObject(0.0f, 0.0f, -0.01f);
            object.get(14).translateObject(0.0f, 0.0f, -0.01f);
            object.get(15).translateObject(0.0f, 0.0f, -0.01f);
            object.get(16).translateObject(0.0f, 0.0f, -0.01f);
            object.get(17).translateObject(0.0f, 0.0f, -0.01f);
            object.get(18).translateObject(0.0f, 0.0f, -0.01f);
            object.get(19).translateObject(0.0f, 0.0f, -0.01f);
            object.get(20).translateObject(0.0f, 0.0f, -0.01f);
            object.get(21).translateObject(0.0f, 0.0f, -0.01f);
            object.get(22).translateObject(0.0f, 0.0f, -0.01f);
            object.get(23).translateObject(0.0f, 0.0f, -0.01f);
            object.get(24).translateObject(0.0f, 0.0f, -0.01f);
            object.get(4).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(5).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(6).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(7).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(8).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(9).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            object.get(10).rotateObject((float) Math.toRadians(0.3f), 0.0625f, 0.0f, 0.0f);
            System.out.println("L");
        }

        //punya samantha
        //buat rotasi villager
        if (window.isKeyPressed(GLFW_KEY_Y)) {
            Vector3f kepala = objectSamantha.get(0).getModel().transformPosition(new Vector3f(0, 0, 0));
            objectSamantha.get(0).translateObject(-kepala.x, -kepala.y, -kepala.z); //untuk maju mundur villager
            objectSamantha.get(0).rotateObject((float) Math.toRadians(1.0), 0.0f, 1.0f, 0.0f); //muter ke kanan
            objectSamantha.get(0).translateObject(kepala.x, kepala.y, kepala.z);
            //buat mata 4 bagian + alis mulut idung
            for (int i = 1; i < objectSamantha.size(); i++) {
                objectSamantha.get(i).translateObject(-kepala.x, -kepala.y, -kepala.z); //untuk maju mundur villager
                objectSamantha.get(i).rotateObject((float) Math.toRadians(1.0), 0.0f, 1.0f, 0.0f); //muter ke kanan
                objectSamantha.get(i).translateObject(kepala.x, kepala.y, kepala.z);
            }
        }
        //villager jalan maju
        if (window.isKeyPressed(GLFW_KEY_V)) {
            int pergerakan = 10;
            if (setSpeed == false) {
                stepSpeed = 0.125f * size / pergerakan;
                setSpeed = true;
            }
            for (int i = 0; i < objectSamantha.size(); i++) {
                objectSamantha.get(i).translateObject(0.0f, 0.0f, 0.01f); //untuk maju mundur villager
            }
            objectSamantha.get(9).translateObject(0.0f, 0.0f, stepSpeed);
            objectSamantha.get(10).translateObject(0.0f, 0.0f, -stepSpeed);
            if (maju == true) {
                step++;
            } else {
                step--;
            }
            if (step == pergerakan) {
                maju = false;
                stepSpeed = -stepSpeed;
            } else if (step == -pergerakan) {
                maju = true;
                stepSpeed = -stepSpeed;
            }
        }

        //villager mundur
        if (window.isKeyPressed(GLFW_KEY_M)) {
            int pergerakan = 10;
            if (setSpeed == false) {
                stepSpeed = 0.125f * size / pergerakan;
                setSpeed = true;
            }
            for (int i = 0; i < objectSamantha.size(); i++) {
                objectSamantha.get(i).translateObject(0.0f, 0.0f, -0.01f); //untuk maju mundur villager
            }
            objectSamantha.get(9).translateObject(0.0f, 0.0f, stepSpeed);
            objectSamantha.get(10).translateObject(0.0f, 0.0f, -stepSpeed);
            if (maju == true) {
                step++;
            } else {
                step--;
            }
            if (step == pergerakan) {
                maju = false;
                stepSpeed = -stepSpeed;
            } else if (step == -pergerakan) {
                maju = true;
                stepSpeed = -stepSpeed;
            }
        }
        //jalan kekanan
        if (window.isKeyPressed(GLFW_KEY_T)) {
            int pergerakan = 10;
            if (setSpeed == false) {
                stepSpeed = 0.125f * size / pergerakan;
                setSpeed = true;
            }
            for (int i = 0; i < objectSamantha.size(); i++) {
                objectSamantha.get(i).translateObject(0.01f, 0.0f, 0.0f);
            }
            objectSamantha.get(9).translateObject(stepSpeed, 0.0f, 0.0f);
            objectSamantha.get(10).translateObject(-stepSpeed, 0.0f, 0.0f);
            if (maju == true) {
                step++;
            } else {
                step--;
            }
            if (step == pergerakan) {
                maju = false;
                stepSpeed = -stepSpeed;
            } else if (step == -pergerakan) {
                maju = true;
                stepSpeed = -stepSpeed;
            }
        }
        //jalan kekiri
        if (window.isKeyPressed(GLFW_KEY_N)) {
            int pergerakan = 10;
            if (setSpeed == false) {
                stepSpeed = 0.125f * size / pergerakan;
                setSpeed = true;
            }
            for (int i = 0; i < objectSamantha.size(); i++) {
                objectSamantha.get(i).translateObject(-0.01f, 0.0f, 0.0f);
            }
            objectSamantha.get(9).translateObject(stepSpeed, 0.0f, 0.0f);
            objectSamantha.get(10).translateObject(-stepSpeed, 0.0f, 0.0f);
            if (maju == true) {
                step++;
            } else {
                step--;
            }
            if (step == pergerakan) {
                maju = false;
                stepSpeed = -stepSpeed;
            } else if (step == -pergerakan) {
                maju = true;
                stepSpeed = -stepSpeed;
            }
        }
    }
}